<?php
/**
 * Plugin Name:       Creedally Custom Multi Blocks
 * Description:       A brief description of custom Gutenberg multiple block Plugin.
 * Version:           0.1.0
 * Requires at least: 4.9
 * Requires PHP:      7.2
 * Author:            Shailesh Parmar
 * Author URI:        https://xyz.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tenup-plugin
 * Domain Path:       /languages
 * Update URI:        https://xyz.com/
 *
 * @package           multiblock
 */



// Useful global constants.
define( 'TENUP_PLUGIN_VERSION', '1.0.0' );
define( 'TENUP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'TENUP_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'TENUP_PLUGIN_INC', TENUP_PLUGIN_PATH . 'includes/' );
define( 'TENUP_PLUGIN_BUILD_PATH', TENUP_PLUGIN_PATH . 'build/' );
define( 'TENUP_PLUGIN_BUILD_URL',  TENUP_PLUGIN_URL . 'build/' );
define( 'TENUP_PLUGIN_BLOCK_DIR', TENUP_PLUGIN_INC . 'blocks/' );

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('pms-main', TENUP_PLUGIN_BUILD_URL . 'src/index.css', array(), time());
});


$is_local_env = in_array( wp_get_environment_type(), [ 'local', 'development' ], true );
$is_local_url = strpos( home_url(), '.test' ) || strpos( home_url(), '.local' );
$is_local     = $is_local_env || $is_local_url;

if ( $is_local && file_exists( __DIR__ . '/build/fast-refresh.php' ) ) {
	require_once __DIR__ . '/build/fast-refresh.php';
	TenUpToolkit\set_build_url_path( basename( __DIR__ ), TENUP_PLUGIN_URL, TENUP_PLUGIN_PATH  );
}


// Require Composer autoloader if it exists.
/*
if ( file_exists( TENUP_PLUGIN_PATH . 'vendor/autoload.php' ) ) {
	require_once TENUP_PLUGIN_PATH . 'vendor/autoload.php';
}*/

// Include files.
require_once TENUP_PLUGIN_PATH . 'includes/post-types.php';
require_once TENUP_PLUGIN_PATH . 'includes/block-cpt.php';
require_once TENUP_PLUGIN_PATH . 'includes/blocks.php';

//require_once TENUP_PLUGIN_INC . 'core.php';
require_once TENUP_PLUGIN_INC . 'utility.php'; 

// Activation/Deactivation.
/*register_activation_hook( __FILE__, '\TenUpPlugin\Core\activate' );
register_deactivation_hook( __FILE__, '\TenUpPlugin\Core\deactivate' );*/

// Bootstrap.
TenUpPlugin\Core\setup();

