const defaultConfig = require("@wordpress/scripts/config/webpack.config");
const path = require('path');

module.exports = {
    ...defaultConfig,
    entry: {
        'author-box': './includes/blocks/author-box/index.js',
        'author-block': './includes/blocks/author-block/index.js',
        'two-input': './includes/blocks/two-input/index.js',
        'post-render':'./includes/blocks/post-render/index.js',
        'random-posts':'./includes/blocks/random-posts/index.js',
        'example-block':'./includes/blocks/example-block/index.js',
        'colorsettings':'./includes/blocks/colorsettings/index.js',
        'custom-slider':'./includes/blocks/custom-slider/index.js',
        'inspector-sidebar':'./includes/blocks/inspector-sidebar/index.js',
        'inspectorcontrols':'./includes/blocks/inspectorcontrols/index.js',
        'hero-block':'./includes/blocks/hero-block/index.js',
        'hero-inside-block':'./includes/blocks/hero-inside-block/index.js',
        'post-picker-item':'./includes/blocks/post-picker-item/index.js',
        'cta-block': './includes/blocks/cta-block/index.js'
    },
    output: {
        path: path.join(__dirname, './build/blocks/'),
        filename: '[name]/editor.js'
    }
}
