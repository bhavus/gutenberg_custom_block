<?php
/**
 * Basic block class
 *
 * @package TenupBlockLibrary\Blocks
 */

namespace TenupBlockLibrary\Blocks;

/**
 * TenupBlock class.
 */
class TenupBlock {
	/**
	 * Name of the block slug.
	 *
	 * @var string
	 */
	protected $block_name;

	/**
	 * Block src directory.
	 *
	 * @var string
	 */
	protected $block_source_directory;

	/**
	 * Constructor
	 *
	 * @param string $name Slug name of the block
	 * @param string $dir  Directory where block.json can be found.
	 */
	public function __construct( $name, $dir = TENUP_BLOCK_LIBRARY_BLOCK_SRC ) {
		$this->block_name             = $name;
		$this->block_source_directory = $dir;
	}

	/**
	 * Register the block.
	 *
	 * @return void
	 */
	public function register_block() {

		// Load the block.json file - this should be WordPress.com VIP friendly.
		ob_start();
		include_once "{$this->block_source_directory}/{$this->block_name}/block.json";
		$block = json_decode( ob_get_clean(), true );

		if ( function_exists( 'register_block_type_from_metadata' ) ) {
			register_block_type_from_metadata(
				"{$this->block_source_directory}/{$this->block_name}", // this is the directory where the block.json is found.
				[
					'render_callback' => [ $this, 'render_block_callback' ],
				]
			);
		} else {
			// Legacy fallback - pre 5.5
			register_block_type(
				$block['name'],
				array_merge(
					[
						'render_callback' => [ $this, 'render_block_callback' ],
						'attributes'      => $block['attributes'],
					],
					$settings
				)
			);
		}
	}

	/**
	 * Render callback method for the block
	 *
	 * @todo Need to handle back compat for pre 5.5 and passing args to locate_template
	 *
	 * @param array  $attributes The blocks attributes
	 * @param string $content    Data returned from InnerBlocks.Content
	 * @param array  $block      Block information such as context.
	 *
	 * @return string The rendered block markup.
	 */
	public function render_block_callback( $attributes, $content, $block ) {

		$template_locations = [
			'partials/blocks/' . $this->block_name . '/markup.php',
			'templates/partials/blocks/' . $this->block_name . '/markup.php',
		];
		ob_start();
		// Look for a template in the theme.
		if ( ! locate_template(
			$template_locations,
			true,
			false,
			[
				'attributes' => $attributes,
				'content'    => $content,
				'block'      => $block,
			]
		) ) {
			// require the default template.
			if ( file_exists( $this->block_source_directory . '/' . $this->block_name . '/markup.php' ) ) {
				require $this->block_source_directory . '/' . $this->block_name . '/markup.php';
			}
		}
		return ob_get_clean();
	}
}
