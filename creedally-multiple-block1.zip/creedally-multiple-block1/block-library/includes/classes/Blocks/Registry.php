<?php
/**
 * Block Registry
 *
 * @package TenupBlockLibrary\Blocks
 */

namespace TenupBlockLibrary\Blocks;

use TenupBlockLibrary\Blocks\TenupBlock;

/**
 * Block registry
 */
class Registry {

	/**
	 * Singleton instance
	 *
	 * @var $instance Plugin Singleton plugin instance
	 */
	public static $instance = null;

	/**
	 * The list of available blocks to be registered.
	 *
	 * @var array
	 */
	protected $all_blocks = [
		'accordion'             => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'accordion-item'        => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'simple-accordion-item' => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'content-grid'          => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'content-grid-item'     => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'button'                => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'tabs'                  => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'tabs-item'             => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'content-slider'        => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
		'content-slide'         => [ 'class' => __NAMESPACE__ . '\TenupBlock' ],
	];

	/**
	 * Lazy initialize the plugin
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new Registry();
		}

		return self::$instance;
	}

	/**
	 * Get all available blocks.
	 *
	 * @return array
	 */
	public function get_available_blocks() {
		if ( apply_filters( 'tenup_register_all_blocks', false ) ) {
			return array_keys( $this->all_blocks );
		}

		/**
		 * Either can be an array of block slugs or an array of blocks such that each
		 * value is an array like [ 'class' => '...', 'dir' => '...', ] where keys are
		 * the block slugs.
		 */
		return apply_filters( 'tenup_available_blocks', [] );
	}

	/**
	 * Enqueue assets for front end
	 *
	 * @return void
	 */
	public function frontend_assets() {
		$blocks = $this->get_available_blocks();

		if ( apply_filters( 'tenup_block_library_enable_frontend_styles', true ) ) {
			foreach ( $blocks as $block_key ) {
				if ( ! apply_filters( 'tenup_block_library_enqueue_' . $block_key . '_styles', true ) ) {
					continue;
				}

				$path = TENUP_BLOCK_LIBRARY_PATH . 'dist/css/frontend-' . $block_key . '-styles.asset.php';

				if ( file_exists( $path ) ) {
					$dep = require_once $path;

					wp_enqueue_style(
						'tenup-block-library-frontend-' . $block_key . '-styles',
						TENUP_BLOCK_LIBRARY_DIST . 'css/frontend-' . $block_key . '-styles.css',
						$dep['dependencies'],
						$dep['version']
					);
				}
			}
		}

		if ( apply_filters( 'tenup_block_library_enable_frontend_scripts', true ) ) {
			foreach ( $blocks as $block_key ) {
				if ( ! apply_filters( 'tenup_block_library_enqueue_' . $block_key . '_scripts', true ) ) {
					continue;
				}

				$path = TENUP_BLOCK_LIBRARY_PATH . 'dist/js/frontend-' . $block_key . '-scripts.asset.php';

				if ( file_exists( $path ) ) {
					$dep = require_once $path;

					wp_enqueue_script(
						'tenup-block-library-frontend-' . $block_key . '-scripts',
						TENUP_BLOCK_LIBRARY_DIST . 'js/frontend-' . $block_key . '-scripts.js',
						$dep['dependencies'],
						$dep['version'],
						true
					);
				}
			}
		}
	}

	/**
	 * Undocumented function
	 *
	 * @return void
	 */
	public function setup() {
		add_action( 'init', [ $this, 'register_tenup_blocks' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_assets' ] );
		add_action( 'rest_api_init', [ $this, 'rest_fields' ] );
	}

	/**
	 * Register needed rest fields
	 */
	public function rest_fields() {
		$post_types = get_post_types(
			[
				'public' => true,
			]
		);

		register_rest_field(
			apply_filters( 'tenup_api_featured_image_post_types', array_keys( $post_types ) ),
			'featured_image_src',
			array(
				'get_callback'    => [ $this, 'rest_featured_image_src' ],
				'update_callback' => null,
				'schema'          => null,
			)
		);
	}

	/**
	 * Get featured image source for the rest field
	 *
	 * @param String $object  The object type.
	 * @param String $field_name  Name of the field to retrieve.
	 * @param String $request  The current request object.
	 */
	public function rest_featured_image_src( $object, $field_name, $request ) {
		$feat_img_array = wp_get_attachment_image_src( $object['featured_media'], 'large' );

		if ( is_array( $feat_img_array ) ) {
			return $feat_img_array[0];
		}
	}

	/**
	 * Register our blocks
	 *
	 * @return void
	 */
	public function register_tenup_blocks() {
		$blocks = $this->get_available_blocks();

		if ( empty( $blocks ) ) {
			return;
		}

		foreach ( $blocks as $name => $block ) {
			$class = $block['class'] ?? __NAMESPACE__ . '\TenupBlock';
			$dir   = $block['dir'] ?? TENUP_BLOCK_LIBRARY_BLOCK_SRC;

			/**
			 * If $block is an array, the key is the slug otherwise
			 * $block is the slug.
			 */
			$name = is_array( $block ) ? $name : $block;

			$block_instance = new $class( $name, $dir );
			$block_instance->register_block();
		}
	}
}
