<?php
/**
 * Block Editor Assets
 *
 * @package TenupBlockLibrary\BlockEditor
 */

namespace TenupBlockLibrary\BlockEditor;

/**
 * Assets class.
 */
class Assets {

	/**
	 * Singleton instance.
	 *
	 * @var $instance Plugin Singleton plugin instance
	 */
	public static $instance = null;

	/**
	 * Lazy initialize the plugin
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new Assets();
		}

		return self::$instance;
	}

	/**
	 * Setup
	 *
	 * @return void
	 */
	public function setup() {
		// Enqueue editor assets.
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_assets' ] );
	}

	/**
	 * Enqueue the common editor JS assets.
	 *
	 * @return void
	 */
	public function enqueue_editor_assets() {
		if ( file_exists( TENUP_BLOCK_LIBRARY_PATH . 'dist/blocks/block-editor/editor.asset.php' ) ) {
			$dep = require_once TENUP_BLOCK_LIBRARY_PATH . 'dist/blocks/block-editor/editor.asset.php';
			wp_enqueue_script(
				'tenup-block-library-editor-script',
				TENUP_BLOCK_LIBRARY_DIST . 'blocks/block-editor/editor.js',
				$dep['dependencies'],
				$dep['version'],
				true
			);
		}
	}
}
