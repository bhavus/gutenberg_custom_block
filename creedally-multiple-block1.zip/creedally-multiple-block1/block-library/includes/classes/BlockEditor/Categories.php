<?php
/**
 * Block Editor Categories
 *
 * @package TenupBlockLibrary\BlockEditor
 */

namespace TenupBlockLibrary\BlockEditor;

/**
 * Categories
 */
class Categories {

	/**
	 * Singleton instance.
	 *
	 * @var $instance Plugin Singleton plugin instance
	 */
	public static $instance = null;

	/**
	 * Lazy initialize the plugin
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new Categories();
		}

		return self::$instance;
	}

	/**
	 * Setup
	 *
	 * @return void
	 */
	public function setup() {
		// Create a block category, use the slug 'tenup-blocks'.
		add_filter( 'block_categories_all', [ $this, 'add_block_category' ] );
	}

	/**
	 * Add the custom 10up Blocks Category to the block lists.
	 *
	 * @param array $categories The list of default Block Categories.
	 *
	 * @return array
	 */
	public function add_block_category( $categories ) {
		return array_merge(
			$categories,
			array(
				array(
					'slug'  => 'tenup-blocks',
					'title' => esc_html__( '10up', '10up-block-library' ),
				),
			)
		);
	}
}
