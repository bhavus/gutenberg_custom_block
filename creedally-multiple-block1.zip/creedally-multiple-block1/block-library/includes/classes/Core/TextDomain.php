<?php
/**
 * Load the text domain for this plugin.
 *
 * @package TenupBlockLibrary\Core
 */

namespace TenupBlockLibrary\Core;

/**
 * TextDomain
 */
class TextDomain {

	/**
	 * Singleton instance
	 *
	 * @var $instance Plugin Singleton plugin instance
	 */
	public static $instance = null;

	/**
	 * Lazy initialize the plugin
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new TextDomain();
		}

		return self::$instance;
	}
	/**
	 * setup function
	 *
	 * @return void
	 */
	public function setup() {
		add_action( 'init', [ $this, 'i18n' ] );
	}

	/**
	 * Register the default textdomain.
	 */
	public function i18n() {
		$locale = apply_filters( 'plugin_locale', get_locale(), '10up-block-library' );
		load_textdomain( '10up-block-library', WP_LANG_DIR . '/plugins/gutenberg-library-' . $locale . '.mo' );
		load_plugin_textdomain( '10up-block-library', false, plugin_basename( TENUP_BLOCK_LIBRARY_PATH ) . '/languages/' );
	}
}
