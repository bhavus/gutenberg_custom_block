/**
 * Wordpress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

const TabsItemSave = () => <InnerBlocks.Content />;
export default TabsItemSave;
