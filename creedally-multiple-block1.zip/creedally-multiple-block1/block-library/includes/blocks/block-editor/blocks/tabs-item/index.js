/**
 * Tabs Item
 */

/**
 * WordPress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import edit from './edit';
import save from './save';
import metadata from './block.json';

const { name } = metadata;

const labels = {
	title: __('Tabs Item', '10up-block-library'),
	description: __('Add a new tab.', '10up-block-library'),
};

export default {
	name,
	settings: {
		...metadata,
		...labels,
		icon: (
			<svg
				width="24"
				height="24"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M18.5 18.5L18.5 8.5L5.5 8.5L5.5 18.5L18.5 18.5ZM19 20C19.5523 20 20 19.5523 20 19L20 8C20 7.44772 19.5523 7 19 7L5 7C4.44772 7 4 7.44771 4 8L4 19C4 19.5523 4.44771 20 5 20L19 20Z"
					fill="black"
				/>
				<path d="M6 6L4 6L4 4L6 4L6 6Z" fill="black" />
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M16.5 12.5H7.5V11.5H16.5V12.5Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M16.5 15.5H7.5V14.5H16.5V15.5Z"
					fill="black"
				/>
			</svg>
		),
		edit,
		save,
	},
};
