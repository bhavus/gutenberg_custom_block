<?php
/**
 * Markup for block
 *
 * @package TenupBlockLibrary\Blocks
 */

if ( empty( $attributes['slideType'] ) ) {
	return;
}

if ( 'post-picker' === $attributes['slideType'] ) {
	if ( empty( $attributes['pickedContent'] ) ) {
		return;
	}
}

$overlay = null;

if ( ! empty( $attributes['overlayColor'] ) ) {
	$overlay = $attributes['overlayColor'];
}

if ( ! empty( $attributes['customOverlayColor'] ) ) {
	$overlay = $attributes['customOverlayColor'];
}

$class_name = ( ! empty( $attributes['className'] ) ) ? $attributes['className'] : '';

$classes = [
	$class_name,
	'content-slide',
	'type-' . $attributes['slideType'],
	'has-background-dim-' . $attributes['dimRatio'],
];

if ( ! empty( $overlay ) ) {
	$classes[] = 'has-overlay-color';
}

if ( ! empty( $overlay ) && preg_match( '#^[a-z0-9]+$#i', $overlay ) ) {
	$classes[] = 'has-' . $overlay . '-background-color';
}

$image_id = null;

if ( 'post-picker' === $attributes['slideType'] && ! empty( $attributes['pickedContent']['featured_image_src'] ) ) {
	$image_id = $attributes['pickedContent']['featured_image_id'];
} elseif ( 'cover' === $attributes['slideType'] && ! empty( $attributes['id'] ) ) {
	$image_id = $attributes['id'];
}

$image_size = apply_filters( 'tenup_block_library_slider_image_size', 'large', $image_id );

?>
<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" style="<?php if ( ! empty( $overlay ) ) : ?>background-color: <?php echo esc_attr( $overlay ); ?><?php endif; ?>">
	<?php if ( 'post-picker' === $attributes['slideType'] && ! empty( $attributes['pickedContent']['featured_image_src'] ) ) : ?>
		<a href="<?php echo esc_url( $attributes['pickedContent']['url'] ); ?>">
			<?php echo wp_kses_post( wp_get_attachment_image( $image_id, $image_size ) ); ?>
		</a>
	<?php elseif ( 'cover' === $attributes['slideType'] && ! empty( $attributes['id'] ) ) : ?>
		<?php echo wp_kses_post( wp_get_attachment_image( $image_id, $image_size ) ); ?>
	<?php endif; ?>

	<?php if ( 'cover' === $attributes['slideType'] && ! empty( $attributes['text'] ) ) : ?>
		<div class="inner-text-wrapper">
			<div class="inner-text">
				<?php echo wp_kses_post( $attributes['text'] ); ?>
			</div>
		</div>
	<?php elseif ( 'post-picker' === $attributes['slideType'] && ! empty( $attributes['pickedContent']['title'] ) ) : ?>
		<div class="inner-text-wrapper">
			<div class="inner-text">
				<a href="<?php echo esc_url( $attributes['pickedContent']['url'] ); ?>"><?php echo wp_kses_post( $attributes['pickedContent']['title'] ); ?></a>
			</div>
		</div>
	<?php endif; ?>
</div>
