/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import edit from './edit';
import save from './save';

import metadata from './block.json';

const { name } = metadata;
const labels = {
	title: __('Content Slide', '10up-block-library'),
	description: __('Either a picked post or custom text and an image.', '10up-block-library'),
};

export default {
	name,
	settings: {
		...metadata,
		...labels,
		icon: (
			<svg
				width="24"
				height="24"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M9.5 6.5V17.5H14.5V6.5H9.5ZM9 5C8.44772 5 8 5.44772 8 6V18C8 18.5523 8.44772 19 9 19H15C15.5523 19 16 18.5523 16 18V6C16 5.44772 15.5523 5 15 5H9Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M4 15.5V8.5H6V15.5H4ZM18 15.5V8.5H20V15.5H18Z"
					fill="black"
				/>
			</svg>
		),
		edit,
		save,
	},
};
