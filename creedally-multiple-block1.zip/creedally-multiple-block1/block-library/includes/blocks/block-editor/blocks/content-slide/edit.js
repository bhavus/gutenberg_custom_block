/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
/* stylelint-disable */
import { applyFilters } from '@wordpress/hooks';
import { __ } from '@wordpress/i18n';
import classnames from 'classnames';
import { ContentSearch } from '@10up/block-components';
import {
	withNotices,
	Spinner,
	RangeControl,
	PanelRow,
	Button,
	PanelBody,
	ToolbarItem,
	ToolbarGroup,
} from '@wordpress/components';
import { getBlobTypeByURL, isBlobURL } from '@wordpress/blob';
import {
	MediaPlaceholder,
	ColorPalette,
	BlockControls,
	InspectorControls,
	MediaReplaceFlow,
	RichText,
	__experimentalPanelColorGradientSettings as PanelColorGradientSettings, // eslint-disable-line
	store as blockEditorStore,
	withColors,
} from '@wordpress/block-editor';
import { compose, withInstanceId } from '@wordpress/compose';
import { withDispatch } from '@wordpress/data';

/**
 * Internal dependencies
 */
import { editPropsShape } from './props-shape';

import './editor.css';

const IMAGE_BACKGROUND_TYPE = 'image';
const VIDEO_BACKGROUND_TYPE = 'video';

const ALLOWED_MEDIA_TYPES = ['image', 'video'];

function attributesFromMedia(setAttributes) {
	return (media) => {
		if (!media || !media.url) {
			setAttributes({ url: undefined, id: undefined });
			return;
		}

		if (isBlobURL(media.url)) {
			media.type = getBlobTypeByURL(media.url);
		}

		let mediaType;
		// for media selections originated from a file upload.
		if (media.media_type) {
			if (media.media_type === IMAGE_BACKGROUND_TYPE) {
				mediaType = IMAGE_BACKGROUND_TYPE;
			} else {
				// only images and videos are accepted so if the media_type is not an image we can assume it is a video.
				// Videos contain the media type of 'file' in the object returned from the rest api.
				mediaType = VIDEO_BACKGROUND_TYPE;
			}
		} else {
			// for media selections originated from existing files in the media library.
			if (media.type !== IMAGE_BACKGROUND_TYPE && media.type !== VIDEO_BACKGROUND_TYPE) {
				return;
			}
			mediaType = media.type;
		}

		setAttributes({
			url: media.url,
			id: media.id,
			backgroundType: mediaType,
			...(mediaType === VIDEO_BACKGROUND_TYPE
				? { focalPoint: undefined, hasParallax: undefined }
				: {}),
		});
	};
}

function dimRatioToClass(ratio) {
	return ratio === 0 || ratio === 50 || !ratio
		? null
		: `has-background-dim-${10 * Math.round(ratio / 10)}`;
}

const isTemporaryMedia = (id, url) => !id && isBlobURL(url);

const allowedSlideTypes = applyFilters('tenup.contentSlider.allowedSlideTypes', [
	'cover',
	'post-picker',
]);

const postPickerPostType = applyFilters('tenup.contentSlider.postType', 'post');

const Edit = ({
	attributes,
	className,
	noticeOperations,
	overlayColor,
	setAttributes,
	setOverlayColor,
}) => {
	const { id, backgroundType, text, dimRatio, slideType, pickedContent, url } = attributes;

	const onSelectMedia = attributesFromMedia(setAttributes);

	const { removeAllNotices, createErrorNotice } = noticeOperations;

	const isUploadingMedia = isTemporaryMedia(id, url);

	const hasBackground = !!(url || overlayColor.color);

	const isImageBackground = IMAGE_BACKGROUND_TYPE === backgroundType;
	const isVideoBackground = VIDEO_BACKGROUND_TYPE === backgroundType;

	const onChangeSlideType = () => {
		setAttributes({
			slideType: undefined,
			url: undefined,
			id: undefined,
			backgroundType: undefined,
			dimRatio: undefined,
			text: undefined,
			pickedContent: undefined,
			overlayColor: undefined,
			customOverlayColor: undefined,
		});
	};

	const classes = classnames(
		dimRatioToClass(dimRatio),
		className,
		`slide-type-${slideType || 'none'}`,
		{
			'has-background-dim': dimRatio !== 0,
			'is-transient': isUploadingMedia,
			[overlayColor.class]: overlayColor.class,
			'has-post': pickedContent,
		},
	);

	if (!slideType && allowedSlideTypes.length) {
		return (
			<div className={`${className} slide-type-none`}>
				<div className="components-placeholder">
					<div className="components-placeholder__label">
						{__('Content Slide', '10up-block-attributes')}
					</div>
					<div className="components-placeholder__instructions">
						{__('What type of content should this slide show?', '10up-block-library')}
					</div>
					<div className="components-placeholder__fieldset">
						<button
							type="button"
							className="components-button block-editor-media-placeholder__button is-tertiary"
							onClick={() => {
								setAttributes({ slideType: 'cover' });
							}}
						>
							{__('Image with Custom Text', '10up-block-library')}
						</button>
						<button
							type="button"
							onClick={() => {
								setAttributes({ slideType: 'post-picker' });
							}}
							className="components-button block-editor-media-placeholder__button is-tertiary"
						>
							{__('Post Picker', '10up-block-library')}
						</button>
					</div>
				</div>
			</div>
		);
	}
	if (slideType === 'cover') {
		return (
			<>
				<BlockControls group="other">
					<MediaReplaceFlow
						mediaId={id}
						mediaURL={url}
						allowedTypes={ALLOWED_MEDIA_TYPES}
						accept="image/*,video/*"
						onSelect={onSelectMedia}
						name={
							!url
								? __('Add Media', '10up-block-library')
								: __('Replace', '10up-block-library')
						}
					/>
					<ToolbarItem onClick={onChangeSlideType} as={Button}>
						{__('Change Slide Type', '10up-block-library')}
					</ToolbarItem>
				</BlockControls>
				<InspectorControls>
					{!!url && (
						<PanelBody title={__('Media settings', '10up-block-library')}>
							<PanelRow>
								<Button
									className="is-secondary"
									onClick={() =>
										setAttributes({
											url: undefined,
											id: undefined,
											backgroundType: undefined,
											dimRatio: undefined,
										})
									}
								>
									{__('Clear Media', '10up-block-library')}
								</Button>
							</PanelRow>
						</PanelBody>
					)}
					<PanelColorGradientSettings
						title={__('Overlay')}
						initialOpen
						gradients={[]}
						disableCustomGradients
						settings={[
							{
								colorValue: overlayColor.color,
								onColorChange: setOverlayColor,
								label: __('Color', '10up-block-library'),
							},
						]}
					>
						{!!url && (
							<RangeControl
								label={__('Opacity', '10up-block-library')}
								value={dimRatio}
								onChange={(newDimRation) =>
									setAttributes({
										dimRatio: newDimRation,
									})
								}
								min={0}
								max={100}
								step={10}
								required
							/>
						)}
					</PanelColorGradientSettings>
				</InspectorControls>
				<div
					className={classes}
					style={{
						backgroundColor: overlayColor.color,
					}}
				>
					{isUploadingMedia && <Spinner />}
					{!hasBackground ? (
						<MediaPlaceholder
							labels={{
								title: __('Image with Text', '10up-block-library'),
								instructions: __(
									'Upload an image or video file, or pick one from your media library.',
									'10up-block-library',
								),
							}}
							onSelect={onSelectMedia}
							accept="image/*,video/*"
							allowedTypes={ALLOWED_MEDIA_TYPES}
							onError={(message) => {
								removeAllNotices();
								createErrorNotice(message);
							}}
						>
							<div className="wp-block-cover__placeholder-background-options">
								<ColorPalette
									disableCustomColors
									value={overlayColor.color}
									onChange={setOverlayColor}
									clearable={false}
								/>
							</div>
						</MediaPlaceholder>
					) : (
						<>
							{url && isImageBackground && (
								<img
									className="wp-block-content-slide__image-background"
									alt={__('Slide image', '10up-block-library')}
									src={url}
								/>
							)}
							{url && isVideoBackground && (
								<video
									className="wp-block-content-slide__video-background"
									autoPlay
									muted
									loop
									src={url}
								/>
							)}
							<div className="slide-content">
								<RichText
									tagName="div"
									value={text}
									onChange={(content) => setAttributes({ text: content })}
									placeholder={__('Enter text…', '10up-block-library')}
									keepPlaceholderOnFocus
								/>
							</div>
						</>
					)}
				</div>
			</>
		);
	}
	return (
		<>
			<BlockControls>
				<ToolbarGroup>
					{pickedContent ? (
						<ToolbarItem
							onClick={() => {
								setAttributes({
									pickedContent: undefined,
									overlayColor: undefined,
									customOverlayColor: undefined,
									dimRatio: 50,
								});
							}}
							as={Button}
						>
							{__('Replace', '10up-block-library')}
						</ToolbarItem>
					) : (
						''
					)}
					<ToolbarItem onClick={onChangeSlideType} as={Button}>
						{__('Change Slide Type', '10up-block-library')}
					</ToolbarItem>
				</ToolbarGroup>
			</BlockControls>
			{pickedContent ? (
				<InspectorControls>
					<PanelColorGradientSettings
						title={__('Overlay', '10up-block-library')}
						initialOpen
						gradients={[]}
						disableCustomGradients
						settings={[
							{
								colorValue: overlayColor.color,
								onColorChange: setOverlayColor,
								label: __('Color', '10up-block-library'),
							},
						]}
					>
						{overlayColor && overlayColor.color && (
							<RangeControl
								label={__('Opacity', '10up-block-library')}
								value={dimRatio}
								onChange={(newDimRation) =>
									setAttributes({
										dimRatio: newDimRation,
									})
								}
								min={0}
								max={100}
								step={10}
								required
							/>
						)}
					</PanelColorGradientSettings>
				</InspectorControls>
			) : (
				''
			)}
			<div
				className={classes}
				style={{
					backgroundColor: overlayColor.color,
				}}
			>
				{pickedContent ? (
					<>
						{pickedContent.featured_image_src && (
							<img
								className="wp-block-content-slide__image-background"
								alt={__('Slide image', '10up-block-library')}
								src={pickedContent.featured_image_src}
							/>
						)}

						<div className="slide-content">
							<a href={pickedContent.url}>{pickedContent.title}</a>
						</div>
					</>
				) : (
					<div className="pick-content-wrapper">
						<div className="components-placeholder__label">
							{__('Pick Content', '10up-block-library')}
						</div>
						<ContentSearch
							onSelectItem={(item) => {
								const preparedPickedContent = {
									title: item.title,
									type: item.type,
									subtype: item.subtype,
									url: item.url,
								};

								if (item?._embedded.self?.[0]?.featured_image_src) {
									preparedPickedContent.featured_image_src =
										item._embedded.self[0].featured_image_src;
									preparedPickedContent.featured_image_id =
										item._embedded.self[0].featured_media;
								}

								setAttributes({ pickedContent: preparedPickedContent });
							}}
							mode="post"
							label={applyFilters(
								'tenup.contentSlider.pickerLabel',
								__('Search content:', '10up-block-library'),
							)}
							contentTypes={[postPickerPostType]}
						/>
					</div>
				)}
			</div>
		</>
	);
};

Edit.propTypes = {
	...editPropsShape,
};

export default compose([
	withDispatch((dispatch) => {
		const { toggleSelection } = dispatch(blockEditorStore);

		return {
			toggleSelection,
		};
	}),
	withColors({ overlayColor: 'background-color' }),
	withNotices,
	withInstanceId,
])(Edit);
