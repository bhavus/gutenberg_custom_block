import { InnerBlocks } from '@wordpress/block-editor';

const ContentSlideSave = () => <InnerBlocks.Content />;
export default ContentSlideSave;
