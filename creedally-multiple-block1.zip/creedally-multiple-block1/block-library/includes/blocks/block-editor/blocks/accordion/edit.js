/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';
import { InnerBlocks } from '@wordpress/block-editor';
import { applyFilters } from '@wordpress/hooks';
import { compose } from '@wordpress/compose';
import { useEffect, useState } from '@wordpress/element';
import { withSelect, withDispatch } from '@wordpress/data';

/**
 * Internal dependencies
 */
import createFilterableComponent from '../../../utils/createFilterableComponent';
import SingleBlockAppender from '../../../components/single-block-appender';
import { editPropsShape } from './props-shape';

import './editor.css';

const FilterableAccordionHeader = createFilterableComponent('tenup.accordion.header');
const FilterableAccordionFooter = createFilterableComponent('tenup.accordion.footer');
const AccordionEdit = (props) => {
	const {
		className,
		clientId,
		removeBlock,
		block: { innerBlocks },
	} = props;

	const itemType = applyFilters('tenup.accordion.itemType', 'text');

	const hasInnerBlocks = !!innerBlocks.length;

	const [hadFirstBlock, setHadFirstBlock] = useState(hasInnerBlocks);

	useEffect(() => {
		setHadFirstBlock(hasInnerBlocks);
	}, [hasInnerBlocks]);

	// Delete parent block if no more inner blocks
	useEffect(() => {
		if (hadFirstBlock && !innerBlocks.length) {
			removeBlock(clientId);
		}
	}, [innerBlocks.length, hadFirstBlock, clientId, removeBlock]);

	return (
		<div className={`${className}`}>
			<FilterableAccordionHeader blockProps={props} />
			<InnerBlocks
				allowedBlocks={[
					itemType === 'text' ? 'tenup/simple-accordion-item' : 'tenup/accordion-item',
				]}
				template={[
					[itemType === 'text' ? 'tenup/simple-accordion-item' : 'tenup/accordion-item'],
				]}
				__experimentalCaptureToolbars
				renderAppender={() => (
					<SingleBlockAppender
						isSecondary
						allowedBlock={
							itemType === 'text'
								? 'tenup/simple-accordion-item'
								: 'tenup/accordion-item'
						}
						buttonText={__('Insert Accordion Item')}
						clientID={clientId}
					/>
				)}
			/>
			<FilterableAccordionFooter blockProps={props} />
		</div>
	);
};

AccordionEdit.propTypes = {
	...editPropsShape,
};

export default compose(
	withSelect((select, { clientId }) => {
		const { getBlock } = select('core/block-editor');

		return {
			block: getBlock(clientId),
		};
	}),
	withDispatch((dispatch) => {
		const { removeBlock } = dispatch('core/block-editor');

		return {
			removeBlock,
		};
	}),
)(AccordionEdit);
