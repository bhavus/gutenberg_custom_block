<?php
/**
 * Markup for the Accordion block wrapper
 *
 * @package TenupBlockLibrary\Blocks
 */

$class_name = ( ! empty( $attributes['className'] ) ) ? $attributes['className'] : '';
?>
<div class="accordion <?php echo esc_attr( $class_name ); ?>">
	<?php echo wp_kses_post( $content ); ?>
</div> <!-- /.accordion -->
