/**
 * Accordion Block
 */

/**
 * WordPress dependencies
 */

/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import edit from './edit';
import save from './save';
import metadata from './block.json';

const { name } = metadata;

const labels = {
	title: __('Accordion', '10up-block-library'),
	description: __(
		'Display headings and content in an accordion format that allows for opening and closing sections.',
		'10up-block-library',
	),
};

export default {
	name,
	settings: {
		...metadata,
		...labels,
		icon: (
			<svg
				width="24"
				height="24"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M5.5 5.5V9.5H18.5V5.5H5.5ZM5 4C4.44772 4 4 4.44772 4 5V10C4 10.5523 4.44772 11 5 11H19C19.5523 11 20 10.5523 20 10V5C20 4.44772 19.5523 4 19 4H5Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M5.5 14.5V18.5H18.5V14.5H5.5ZM5 13C4.44772 13 4 13.4477 4 14V19C4 19.5523 4.44772 20 5 20H19C19.5523 20 20 19.5523 20 19V14C20 13.4477 19.5523 13 19 13H5Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M16.5 8H13.5V7H16.5V8Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M16.5 17H13.5V16H16.5V17Z"
					fill="black"
				/>
			</svg>
		),
		edit,
		save,
	},
};
