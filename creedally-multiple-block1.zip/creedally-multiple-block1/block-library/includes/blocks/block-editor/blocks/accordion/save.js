/**
 * Wordpress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

const AccordionSave = () => <InnerBlocks.Content />;
export default AccordionSave;
