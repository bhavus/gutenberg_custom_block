/**
 * External dependencies
 */
import PropTypes from 'prop-types';

export const propsShape = {
	attributes: PropTypes.object.isRequired,
	clientId: PropTypes.string.isRequired,
};

export const editPropsShape = {
	...propsShape,
	setAttributes: PropTypes.func.isRequired,
};

export const panelPropShape = {
	...propsShape,
	setAttributes: PropTypes.func.isRequired,
};
