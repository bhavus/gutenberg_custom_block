/**
 * Wordpress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

const TabsSave = () => <InnerBlocks.Content />;
export default TabsSave;
