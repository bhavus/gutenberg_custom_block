/**
 * Wordpress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

const AccordionItemSave = () => <InnerBlocks.Content />;
export default AccordionItemSave;
