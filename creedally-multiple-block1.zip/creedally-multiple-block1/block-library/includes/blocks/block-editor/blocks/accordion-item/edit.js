/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';
import { InnerBlocks, RichText } from '@wordpress/block-editor';
import { compose } from '@wordpress/compose';

/**
 * Internal dependencies
 */
import withHasSelectedInnerBlock from '../../../hoc/with-has-selected-inner-block';
import { editPropsShape } from './props-shape';
import createFilterableComponent from '../../../utils/createFilterableComponent';
import CustomBlockAppender from '../../../components/custom-block-appender';

const FilterableAccordionItemHeader = createFilterableComponent('tenup.accordionItem.header');
const FilterableAccordionItemFooter = createFilterableComponent('tenup.accordionItem.footer');

const AccordionItemEdit = (props) => {
	const { isSelected, attributes, setAttributes, clientId } = props;
	const { header } = attributes;
	const tagName = isSelected ? 'div' : 'button';
	return (
		<>
			<FilterableAccordionItemHeader blockProps={props}>
				<RichText
					placeholder={__('Enter accordion section headline', '10up-block-library')}
					value={header}
					onChange={(value) => setAttributes({ header: value })}
					tagName={tagName}
					className="accordion-header"
				/>
			</FilterableAccordionItemHeader>
			<div className="accordion-content is-active">
				<InnerBlocks
					templateInsertUpdatesSelection
					__experimentalCaptureToolbars
					renderAppender={() => (
						<CustomBlockAppender
							className="accordion-item-appender"
							rootClientId={clientId}
							isTertiary
							showTooltip
							label={__('Insert Accordion content', '10up-block-library')}
						/>
					)}
				/>
			</div>
			<FilterableAccordionItemFooter blockProps={props} />
		</>
	);
};

AccordionItemEdit.propTypes = {
	...editPropsShape,
};

export default compose(withHasSelectedInnerBlock())(AccordionItemEdit);
