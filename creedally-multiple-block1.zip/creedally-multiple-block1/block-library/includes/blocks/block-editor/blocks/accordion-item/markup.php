<?php
/**
 * Markup for the Accordion Item block
 *
 * @package TenupBlockLibrary\Blocks
 */

?>

<button class="accordion-header" type="button"><?php echo wp_kses_post( $attributes['header'] ); ?></button>
<div class="accordion-content">
	<?php echo wp_kses_post( $content ); ?>
</div>
