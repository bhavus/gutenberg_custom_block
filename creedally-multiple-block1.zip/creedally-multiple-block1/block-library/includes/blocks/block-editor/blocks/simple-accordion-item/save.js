/**
 * Wordpress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

const SimpleAccordionItemSave = () => <InnerBlocks.Content />;
export default SimpleAccordionItemSave;
