/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';
import { RichText } from '@wordpress/block-editor';

/**
 * Internal dependencies
 */
import { editPropsShape } from './props-shape';
import createFilterableComponent from '../../../utils/createFilterableComponent';

const FilterableAccordionItemHeader = createFilterableComponent('tenup.simpleAccordionItem.header');
const FilterableAccordionItemFooter = createFilterableComponent('tenup.simpleAccordionItem.footer');

const SimpleAccordionItemEdit = (props) => {
	const {
		setAttributes,
		className,
		attributes: { header, content },
	} = props;

	return (
		<div className={`${className}`}>
			<FilterableAccordionItemHeader blockProps={props}>
				<div className="accordion-header-container">
					<RichText
						allowedFormats={[]}
						tagName="span"
						value={header}
						onChange={(value) =>
							setAttributes({ header: value.replace(/[\r\n\t]+/gm, ' ') })
						}
						placeholder={__('Enter accordion section headline', '10up-block-library')}
						keepPlaceholderOnFocus
						className="accordion-header"
					/>
				</div>
			</FilterableAccordionItemHeader>
			<div>
				<RichText
					tagName="div"
					value={content}
					onChange={(value) => setAttributes({ content: value })}
					placeholder={__('Enter accordion section content', '10up-block-library')}
					keepplaceholderonfocus
				/>
			</div>
			<FilterableAccordionItemFooter blockProps={props} />
		</div>
	);
};

SimpleAccordionItemEdit.propTypes = {
	...editPropsShape,
};
export default SimpleAccordionItemEdit;
