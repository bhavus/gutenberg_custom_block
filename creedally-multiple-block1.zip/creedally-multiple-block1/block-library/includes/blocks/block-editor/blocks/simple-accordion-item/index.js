/**
 * Simple Accordion Item Block
 */

/**
 * WordPress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import edit from './edit';
import save from './save';
import metadata from './block.json';

const { name } = metadata;

const labels = {
	title: __('Accordion Item', '10up-block-library'),
	description: __(
		'Add an accordion item to display content inside an accordion.',
		'10up-block-library',
	),
};

export default {
	name,
	settings: {
		...metadata,
		...labels,
		icon: (
			<svg
				width="125"
				height="118"
				viewBox="0 0 125 118"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M119 6H6V112H119V6ZM0 0V118H125V0H0Z"
					fill="#404040"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M111 45.0382H12V39.0382H111V45.0382Z"
					fill="#404040"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M111 70.2596H12V64.2596H111V70.2596Z"
					fill="#404040"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M111 95.4809H12V89.4809H111V95.4809Z"
					fill="#404040"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M12 15.5L26 15.5L26 20.5L12 20.5L12 15.5Z"
					fill="#404040"
				/>
			</svg>
		),
		edit,
		save,
	},
};
