<?php
/**
 * Markup for the Content Grid block
 *
 * @package TenupBlockLibrary\Blocks
 */

$class_name = ( ! empty( $attributes['className'] ) ) ? $attributes['className'] : '';
?>
<div class="content-grid <?php echo esc_attr( $class_name ); ?> cols-<?php echo esc_attr( $attributes['columns'] ); ?>">
	<?php echo wp_kses_post( $content ); ?>
</div>
