import { InnerBlocks } from '@wordpress/block-editor';

const ContentGridSave = () => <InnerBlocks.Content />;

export default ContentGridSave;
