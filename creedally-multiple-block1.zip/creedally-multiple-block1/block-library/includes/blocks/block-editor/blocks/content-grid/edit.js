/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { applyFilters } from '@wordpress/hooks';
import { useSelect, withDispatch } from '@wordpress/data';
import { compose } from '@wordpress/compose';
import { PanelBody } from '@wordpress/components';
import { useEffect, useState } from '@wordpress/element';
import { InnerBlocks, InspectorControls } from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import createFilterableComponent from '../../../utils/createFilterableComponent';
import { editPropsShape } from './props-shape';

import './editor.css';

const FilterableContentGridHeader = createFilterableComponent('tenup.contentGrid.header');
const FilterableContentGridFooter = createFilterableComponent('tenup.contentGrid.footer');
const ContentGridEdit = (props) => {
	const {
		className,
		clientId,
		removeBlock,
		setAttributes,
		attributes: { columns },
	} = props;

	const innerBlocks = useSelect(
		(select) => select('core/block-editor').getBlock(clientId).innerBlocks,
	);

	const hasInnerBlocks = !!innerBlocks.length;

	const [hadFirstBlock, setHadFirstBlock] = useState(hasInnerBlocks);

	useEffect(() => {
		setHadFirstBlock(hasInnerBlocks);
	}, [hasInnerBlocks]);

	// Delete parent block if no more inner blocks
	useEffect(() => {
		if (hadFirstBlock && !innerBlocks.length) {
			removeBlock(clientId);
		}
	}, [innerBlocks.length, hadFirstBlock, clientId, removeBlock]);

	return (
		<>
			<InspectorControls>
				<PanelBody title={__('Display Options', '10up-block-library')}>
					<label htmlFor="content-grid-columns">
						{__('Number of columns:', '10up-block-library')}
					</label>{' '}
					<select
						id="content-grid-columns"
						defaultValue={columns}
						aria-label={__('Number of columns', '10up-block-library')}
						onChange={(event) =>
							setAttributes({ columns: parseInt(event.target.value, 10) })
						}
					>
						{[...Array(applyFilters('tenup.contentGrid.maxColumns', 4)).keys()].map(
							(index) => (
								<option key={index} value={index + 1}>
									{index + 1}
								</option>
							),
						)}
					</select>
				</PanelBody>
			</InspectorControls>
			<div className={`${className} cols-${columns}`}>
				<FilterableContentGridHeader blockProps={props} />
				<InnerBlocks
					allowedBlocks={applyFilters('tenup.contentGrid.allowedBlocks', [
						'tenup/content-grid-item',
					])}
					orientation="horizontal"
					template={applyFilters('tenup.contentGrid.template', [
						['tenup/content-grid-item'],
					])}
					__experimentalCaptureToolbars
					renderAppender={() => <InnerBlocks.ButtonBlockAppender />}
				/>
				<FilterableContentGridFooter blockProps={props} />
			</div>
		</>
	);
};

ContentGridEdit.propTypes = {
	...editPropsShape,
};

export default compose(
	withDispatch((dispatch) => {
		const { removeBlock } = dispatch('core/block-editor');

		return {
			removeBlock,
		};
	}),
)(ContentGridEdit);
