// Since this is a dynamic block, we return null.
const save = () => {
	return null;
};

export default save;
