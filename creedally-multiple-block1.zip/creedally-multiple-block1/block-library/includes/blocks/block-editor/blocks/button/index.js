/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import edit from './edit';
import save from './save';

import metadata from './block.json';

const { name } = metadata;
const labels = {
	title: __('Button', '10up-block-library'),
	description: __('Add a single button-style link for emphasis.', '10up-block-library'),
};

export default {
	name,
	settings: {
		...metadata,
		...labels,
		icon: (
			<svg
				width="24"
				height="24"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M5.5 14.5L18.5 14.5L18.5 9.5L5.5 9.5L5.5 14.5ZM4 15C4 15.5523 4.44772 16 5 16L19 16C19.5523 16 20 15.5523 20 15L20 9C20 8.44772 19.5523 8 19 8L5 8C4.44771 8 4 8.44772 4 9L4 15Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M16 12.5H8V11.5H16V12.5Z"
					fill="black"
				/>
			</svg>
		),
		edit,
		save,
	},
};
