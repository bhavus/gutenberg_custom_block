import PropTypes from 'prop-types';

export const propsShape = {
	attributes: PropTypes.shape({
		buttonTarget: PropTypes.boolean,
		buttonText: PropTypes.string,
		buttonUrl: PropTypes.string,
	}).isRequired,
	clientId: PropTypes.string,
};

export const editPropsShape = {
	...propsShape,
	setAttributes: PropTypes.func.isRequired,
};

export const panelPropShape = {
	...propsShape,
	setAttributes: PropTypes.func.isRequired,
};
