/* eslint-disable react/jsx-props-no-spreading */
/**
 * WordPress dependencies
 */
// eslint-disable-next-line import/no-extraneous-dependencies
import { Fragment } from '@wordpress/element';
import { useBlockProps } from '@wordpress/block-editor';

/**
 * Internal dependencies
 */
import Button from '../../../components/button';
import { editPropsShape } from './props-shape';
import createFilterableComponent from '../../../utils/createFilterableComponent';
import URLPicker from '../../../components/url-picker';

// Create some filterableComponents
const FilterableButtons = createFilterableComponent('tenup.button');

const ButtonEdit = (props) => {
	const {
		attributes: { text, url, linkTarget, rel },
		isSelected,
		setAttributes,
	} = props;

	const blockProps = useBlockProps();

	return (
		<Fragment>
			<URLPicker
				url={url}
				setAttributes={setAttributes}
				isSelected={isSelected}
				opensInNewTab={linkTarget === '_blank'}
				anchorRef={blockProps.ref}
				rel={rel}
			/>
			<div {...blockProps}>
				<div className="tenup-button-group">
					<FilterableButtons blockProps={props}>
						<Button
							key="tenup-button"
							text={text}
							onChange={(text) => setAttributes({ text })}
						/>
					</FilterableButtons>
				</div>
			</div>
		</Fragment>
	);
};

ButtonEdit.propTypes = {
	...editPropsShape,
};

export default ButtonEdit;
