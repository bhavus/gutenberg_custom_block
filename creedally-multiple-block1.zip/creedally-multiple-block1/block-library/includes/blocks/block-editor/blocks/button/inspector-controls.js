/**
 * WordPress dependencies
 */
import { PanelBody, ToggleControl } from '@wordpress/components';
import { URLInput } from '@wordpress/block-editor';
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import { panelPropShape } from './props-shape';

export const ButtonOptions = ({ setAttributes, attributes: { buttonTarget, buttonUrl } }) => (
	<PanelBody title={__('Button Options', '10up-block-library')}>
		<ToggleControl
			label={__('Open link in new window', '10up-block-library')}
			checked={buttonTarget}
			onChange={() => setAttributes({ buttonTarget: !buttonTarget })}
		/>
		<URLInput
			className="button-url"
			value={buttonUrl}
			onChange={(url) => setAttributes({ buttonUrl: url })}
		/>
	</PanelBody>
);

ButtonOptions.propTypes = {
	...panelPropShape,
};
