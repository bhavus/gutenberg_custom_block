<?php
/**
 * Markup for the Button block
 *
 * @package TenupBlockLibrary\Blocks
 */

$text        = isset( $attributes['text'] ) ? $attributes['text'] : '';
$url         = isset( $attributes['url'] ) ? $attributes['url'] : '';
$link_target = isset( $attributes['linkTarget'] ) ? $attributes['linkTarget'] : '';
$rel         = isset( $attributes['rel'] ) ? $attributes['rel'] : '';
$class_name  = ( ! empty( $attributes['className'] ) ) ? $attributes['className'] : '';
?>
<div class="tenup-button-group <?php echo esc_attr( $class_name ); ?>">
	<div class="wp-block-button">
		<?php
		if ( $link_target ) {
			printf(
				'<a class="wp-block-button__link" href="%1$s" target="_blank" rel="%2$s">%3$s %4$s</a>',
				esc_url( $url ),
				esc_attr( $rel ),
				wp_kses_post( $text ),
				'<span class="screen-reader-text">' . esc_html__( '(opens in a new tab)', '10up-block-library' ) . '</span>'
			);
		} else {
			printf(
				'<a class="wp-block-button__link" href="%1$s">%2$s</a>',
				esc_url( $url ),
				wp_kses_post( $text )
			);
		}
		?>
	</div>
</div>
