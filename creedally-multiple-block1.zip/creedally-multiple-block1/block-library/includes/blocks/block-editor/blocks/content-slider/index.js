/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import edit from './edit';
import save from './save';

import metadata from './block.json';

const { name } = metadata;
const labels = {
	title: __('Content Slider', '10up-block-library'),
	description: __('Display text, images, and posts in a carousel format.', '10up-block-library'),
};

export default {
	name,
	settings: {
		...metadata,
		...labels,
		icon: (
			<svg
				width="24"
				height="24"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M5.5 5.5V15.5H18.5V5.5H5.5ZM5 4C4.44772 4 4 4.44772 4 5V16C4 16.5523 4.44772 17 5 17H19C19.5523 17 20 16.5523 20 16V5C20 4.44772 19.5523 4 19 4H5Z"
					fill="black"
				/>
				<path d="M7 18H9V20H7V18Z" fill="black" />
				<path d="M11 18H13V20H11V18Z" fill="black" />
				<path d="M15 18H17V20H15V18Z" fill="black" />
			</svg>
		),
		edit,
		save,
	},
};
