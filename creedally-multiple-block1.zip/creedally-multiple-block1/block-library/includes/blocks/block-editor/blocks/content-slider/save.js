import { InnerBlocks } from '@wordpress/block-editor';

const ContentSliderSave = () => <InnerBlocks.Content />;
export default ContentSliderSave;
