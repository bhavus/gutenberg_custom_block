/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { applyFilters } from '@wordpress/hooks';
import { useSelect, withDispatch } from '@wordpress/data';
import { compose } from '@wordpress/compose';
import {
	PanelBody,
	__experimentalUseCustomUnits as useCustomUnits, // eslint-disable-line @wordpress/no-unsafe-wp-apis
	BaseControl,
} from '@wordpress/components';
import { useEffect, useState } from '@wordpress/element';
import {
	InspectorControls,
	__experimentalUnitControl as UnitControl, // eslint-disable-line @wordpress/no-unsafe-wp-apis
	useSetting,
} from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';

import { InnerBlockSlider } from '@10up/block-components';

/**
 * Internal dependencies
 */
import createFilterableComponent from '../../../utils/createFilterableComponent';
import { editPropsShape } from './props-shape';

import './editor.css';

const FilterableContentSliderHeader = createFilterableComponent('tenup.contentSlider.header');
const FilterableContentSliderFooter = createFilterableComponent('tenup.contentSlider.footer');

const Edit = (props) => {
	const {
		className,
		clientId,
		removeBlock,
		setAttributes,
		attributes: { slidesPerPage, heightUnit, height },
	} = props;

	const innerBlocks = useSelect(
		(select) => select('core/block-editor').getBlock(clientId).innerBlocks,
	);

	const hasInnerBlocks = !!innerBlocks.length;

	const [hadFirstBlock, setHadFirstBlock] = useState(hasInnerBlocks);

	useEffect(() => {
		setHadFirstBlock(hasInnerBlocks);
	}, [hasInnerBlocks]);

	// Delete parent block if no more inner blocks
	useEffect(() => {
		if (hadFirstBlock && !innerBlocks.length) {
			removeBlock(clientId);
		}
	}, [innerBlocks.length, hadFirstBlock, clientId, removeBlock]);

	const units = useCustomUnits({
		availableUnits: useSetting('spacing.units') || ['px', 'em', 'rem', 'vw', 'vh'],
		defaultValues: { px: '450', em: '20', rem: '20', vw: '20', vh: '50' },
	});

	return (
		<>
			<InspectorControls>
				<PanelBody title={__('Display Options', '10up-block-library')}>
					<label htmlFor="content-slider-slides-per-page">
						{__('Slides Per Page', '10up-block-library')}
					</label>{' '}
					<select
						id="content-grid-columns"
						defaultValue={slidesPerPage}
						aria-label={__('Slides per Page', '10up-block-library')}
						onChange={(event) =>
							setAttributes({ slidesPerPage: parseInt(event.target.value, 10) })
						}
					>
						{[
							...Array(
								applyFilters('tenup.contentSlider.maxSlidesPerPage', 4),
							).keys(),
						].map((index) => (
							<option key={index} value={index + 1}>
								{index + 1}
							</option>
						))}
					</select>
				</PanelBody>
				<PanelBody title={__('Dimensions', '10up-block-library')}>
					<BaseControl
						label={__('Slide height', '10up-block-library')}
						id={`height-input-${clientId}`}
					>
						<UnitControl
							id={`height-input-${clientId}`}
							isResetValueOnUnitChange
							onBlur={(newHeight) => {
								setAttributes({ height: parseFloat(newHeight) });
							}}
							onChange={(newHeight) => {
								setAttributes({ height: parseFloat(newHeight) });
							}}
							onUnitChange={(newUnit) => {
								setAttributes({ heightUnit: newUnit });
							}}
							step="1"
							style={{ maxWidth: 80 }}
							unit={heightUnit}
							units={units}
							value={height}
						/>
					</BaseControl>
				</PanelBody>
			</InspectorControls>
			<div className={`${className}`}>
				<FilterableContentSliderHeader blockProps={props} />

				<InnerBlockSlider
					allowedBlock="tenup/content-slide"
					slidesPerPage={slidesPerPage}
					parentBlockId={clientId}
					slideHeight={height && heightUnit ? `${height}${heightUnit}` : '450px'}
				/>
				<FilterableContentSliderFooter blockProps={props} />
			</div>
		</>
	);
};

Edit.propTypes = {
	...editPropsShape,
};

export default compose(
	withDispatch((dispatch) => {
		const { removeBlock } = dispatch('core/block-editor');

		return {
			removeBlock,
		};
	}),
)(Edit);
