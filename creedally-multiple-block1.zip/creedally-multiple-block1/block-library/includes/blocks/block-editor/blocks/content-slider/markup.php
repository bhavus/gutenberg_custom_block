<?php
/**
 * Markup for block
 *
 * @package TenupBlockLibrary\Blocks
 */

$class_name = ( ! empty( $attributes['className'] ) ) ? $attributes['className'] : '';

$height = '480px';
if ( ! empty( $attributes['height'] ) && ! empty( $attributes['heightUnit'] ) ) {
	$height = $attributes['height'] . $attributes['heightUnit'];
}
?>
<div class="content-slider <?php echo esc_attr( $class_name ); ?>" data-slides-per-page="<?php echo (int) $attributes['slidesPerPage']; ?>">
	<div style="--slider-height: <?php echo esc_attr( $height ); ?>;" class="content-slider-inner">
		<?php echo wp_kses_post( $content ); ?>
	</div>
</div>
