import PropTypes from 'prop-types';

export const propsShape = {
	attributes: PropTypes.shape({
		pickedContent: PropTypes.object,
	}).isRequired,
};

export const editPropsShape = {
	...propsShape,
	setAttributes: PropTypes.func.isRequired,
};

export const panelPropShape = {
	...propsShape,
	setAttributes: PropTypes.func.isRequired,
};
