<?php
/**
 * Markup for the Content Grid Item block
 *
 * @package TenupBlockLibrary\Blocks
 */

if ( empty( $attributes['pickedContent'] ) ) {
	return;
}

$picked_post = get_post( $attributes['pickedContent']['id'] );

if ( empty( $picked_post ) ) {
	return;
}

$class_name = ( ! empty( $attributes['className'] ) ) ? $attributes['className'] : '';
?>
<div class="content-grid-item <?php echo esc_attr( $class_name ); ?>">
	<?php if ( has_post_thumbnail( $picked_post ) ) : ?>
		<div class="thumbnail">
			<?php echo wp_kses_post( get_the_post_thumbnail( $picked_post ) ); ?>
		</div>
	<?php endif; ?>

	<h2>
		<a href="<?php echo esc_url( get_permalink( $picked_post ) ); ?>">
			<?php echo esc_html( get_the_title( $picked_post ) ); ?>
		</a>
	</h2>

	<p>
		<?php echo wp_kses_post( get_the_excerpt( $picked_post ) ); ?>
	</p>
</div>
