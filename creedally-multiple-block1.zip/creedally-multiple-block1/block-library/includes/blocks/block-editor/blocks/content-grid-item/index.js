/**
 * Wordpress dependencies
 */
/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';

/**
 * Internal dependencies
 */
import edit from './edit';
import save from './save';

import metadata from './block.json';

const { name } = metadata;
const labels = {
	title: __('Content Grid Item', '10up-block-library'),
	description: __('Add a card to your content grid.', '10up-block-library'),
};

export default {
	name,
	settings: {
		...metadata,
		...labels,
		icon: (
			<svg
				width="24"
				height="24"
				viewBox="0 0 24 24"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M11 10C11 10.5523 10.5523 11 10 11L5 11C4.44771 11 4 10.5523 4 10L4 5C4 4.44772 4.44772 4 5 4L10 4C10.5523 4 11 4.44772 11 5L11 10Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M9.5 9.5L9.5 5.5L5.5 5.5L5.5 9.5L9.5 9.5ZM10 11C10.5523 11 11 10.5523 11 10L11 5C11 4.44772 10.5523 4 10 4L5 4C4.44772 4 4 4.44772 4 5L4 10C4 10.5523 4.44771 11 5 11L10 11Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M18.5 9.5L18.5 5.5L14.5 5.5L14.5 9.5L18.5 9.5ZM19 11C19.5523 11 20 10.5523 20 10L20 5C20 4.44772 19.5523 4 19 4L14 4C13.4477 4 13 4.44772 13 5L13 10C13 10.5523 13.4477 11 14 11L19 11Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M9.5 18.5L9.5 14.5L5.5 14.5L5.5 18.5L9.5 18.5ZM10 20C10.5523 20 11 19.5523 11 19L11 14C11 13.4477 10.5523 13 10 13L5 13C4.44772 13 4 13.4477 4 14L4 19C4 19.5523 4.44771 20 5 20L10 20Z"
					fill="black"
				/>
				<path
					fillRule="evenodd"
					clipRule="evenodd"
					d="M18.5 18.5L18.5 14.5L14.5 14.5L14.5 18.5L18.5 18.5ZM19 20C19.5523 20 20 19.5523 20 19L20 14C20 13.4477 19.5523 13 19 13L14 13C13.4477 13 13 13.4477 13 14L13 19C13 19.5523 13.4477 20 14 20L19 20Z"
					fill="black"
				/>
			</svg>
		),
		edit,
		save,
	},
};
