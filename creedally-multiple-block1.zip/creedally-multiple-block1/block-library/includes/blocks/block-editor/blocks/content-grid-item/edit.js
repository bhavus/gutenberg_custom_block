/* eslint-disable react/jsx-props-no-spreading */
/**
 * WordPress dependencies
 */
// eslint-disable-next-line import/no-extraneous-dependencies
import { __ } from '@wordpress/i18n';
import { applyFilters } from '@wordpress/hooks';
import ServerSideRender from '@wordpress/server-side-render';
import { ContentSearch } from '@10up/block-components';
import { BlockControls } from '@wordpress/block-editor';
import { ToolbarGroup, ToolbarItem, Button } from '@wordpress/components';

/**
 * Internal dependencies
 */
import { editPropsShape } from './props-shape';

const ContentGridItemEdit = (props) => {
	const {
		attributes: { pickedContent },
		className,
		setAttributes,
	} = props;

	const onReplace = () => {
		setAttributes({ pickedContent: null });
	};

	return (
		<>
			{pickedContent ? (
				<BlockControls>
					<ToolbarGroup>
						<ToolbarItem onClick={onReplace} as={Button}>
							{__('Replace', '10up-block-library')}
						</ToolbarItem>
					</ToolbarGroup>
				</BlockControls>
			) : (
				''
			)}
			<div className={`${className}`}>
				{pickedContent ? (
					<ServerSideRender
						block="tenup/content-grid-item"
						attributes={{ pickedContent }}
					/>
				) : (
					<div className="components-placeholder block-editor-media-placeholder is-large">
						<div className="components-placeholder__label">
							{__('Content Grid Item', '10up-block-attributes')}
						</div>
						<ContentSearch
							onSelectItem={(item) => {
								setAttributes({ pickedContent: item });
							}}
							mode="post"
							label={applyFilters(
								'tenup.contentGrid.pickerLabel',
								__('Search posts:', '10up-block-library'),
							)}
							contentTypes={applyFilters('tenup.contentGrid.postTypes', ['post'])}
						/>
					</div>
				)}
			</div>
		</>
	);
};

ContentGridItemEdit.propTypes = {
	...editPropsShape,
};

export default ContentGridItemEdit;
