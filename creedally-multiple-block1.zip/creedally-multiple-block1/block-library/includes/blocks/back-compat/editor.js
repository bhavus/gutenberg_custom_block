/**
 * Internal dependencies
 */
import { registerTenupBlocks } from '../utils/register-block';
import isLodash from '../utils/isLodash';
import accordion from '../block-editor/blocks/accordion';
import accordionItem from '../block-editor/blocks/accordion-item';
import button from '../block-editor/blocks/button';
import contentGridItem from '../block-editor/blocks/content-grid-item';
import contentGrid from '../block-editor/blocks/content-grid';
import tabs from '../block-editor/blocks/tabs';
import tabsItem from '../block-editor/blocks/tabs-item';
import simpleAccordionItem from '../block-editor/blocks/simple-accordion-item';
import contentSlider from '../block-editor/blocks/content-slider';
import contentSlide from '../block-editor/blocks/content-slide';

if (isLodash()) {
	// eslint-disable-next-line no-undef
	_.noConflict();
}

// Register the blocks
// wp.domReady is required for core filters to work with our custom blocks. See - https://github.com/WordPress/gutenberg/issues/9757
wp.domReady(function () {
	const blocks = [
		accordion,
		accordionItem,
		simpleAccordionItem,
		button,
		contentGridItem,
		contentGrid,
		tabs,
		tabsItem,
		contentSlider,
		contentSlide,
	];
	registerTenupBlocks(blocks);
});
