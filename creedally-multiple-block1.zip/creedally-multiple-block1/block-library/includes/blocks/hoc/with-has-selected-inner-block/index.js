/* eslint-disable consistent-return */
/* eslint-disable react/prop-types */
/**
 * WordPress Imports
 */
const { createHigherOrderComponent } = wp.compose;
const { select } = wp.data;

const withHasSelectedInnerBlock = () =>
	createHigherOrderComponent(
		(OriginalComponent) => (props) => {
			const hasSelectedInnerBlock = () => {
				const { clientId } = props;
				const editor = select('core/block-editor');
				const block = editor.getBlock(clientId);
				if (!block) {
					return;
				}

				const selected = editor.getBlockSelectionStart();
				const inner = block.innerBlocks;
				for (let i = 0; i < inner.length; i += 1) {
					if (
						inner[i].clientId === selected ||
						(inner[i].innerBlocks.length && hasSelectedInnerBlock(inner[i]))
					) {
						return true;
					}
				}
				return false;
			};

			// eslint-disable-next-line react/jsx-props-no-spreading
			return <OriginalComponent hasSelectedInnerBlock={hasSelectedInnerBlock} {...props} />;
		},
		'withHasSelectedInnerBlock',
	);

export default withHasSelectedInnerBlock;
