/**
 * External dependencies
 */
import PropTypes from 'prop-types';

/**
 * WordPress dependencies
 */
// eslint-disable-next-line import/no-extraneous-dependencies
import { __ } from '@wordpress/i18n';
// eslint-disable-next-line import/no-extraneous-dependencies
import { useState, Fragment, useCallback } from '@wordpress/element';
// eslint-disable-next-line import/no-extraneous-dependencies
import { rawShortcut, displayShortcut } from '@wordpress/keycodes';
import { KeyboardShortcuts, ToolbarButton, ToolbarGroup, Popover } from '@wordpress/components';
import { BlockControls, __experimentalLinkControl as LinkControl } from '@wordpress/block-editor'; // eslint-disable-line @wordpress/no-unsafe-wp-apis
import { link, linkOff } from '@wordpress/icons';

// Default rel content.
const NEW_TAB_REL = 'external noreferrer noopener';

/**
 * URL Picker
 *
 * @param {Object} props                 Component Props
 * @param {boolean} props.isSelected     selection state of the block
 * @param {string} props.url             currently selected URL
 * @param {string} props.rel             currently selected rel attribute
 * @param {Function} props.setAttributes handler to set attributes for the block
 * @param {boolean} props.opensInNewTab  opens in new tab
 * @param {Object} props.anchorRef       ref of the anchor element
 * @return {*} React JSX
 */
const URLPicker = ({ isSelected, url, rel, setAttributes, opensInNewTab, anchorRef }) => {
	const [isURLPickerOpen, setIsURLPickerOpen] = useState(false);
	const urlIsSet = !!url;
	const urlIsSetAndSelected = urlIsSet && isSelected;
	const openLinkControl = () => {
		setIsURLPickerOpen(true);
		return false; // prevents default behaviour for event
	};
	const unlinkButton = () => {
		setAttributes({
			url: undefined,
			linkTarget: undefined,
			rel: undefined,
		});
		setIsURLPickerOpen(false);
	};

	const onToggleOpenInNewTab = useCallback(
		(value) => {
			const newLinkTarget = value ? '_blank' : undefined;

			let updatedRel = rel;
			if (newLinkTarget && !rel) {
				updatedRel = NEW_TAB_REL;
			} else if (!newLinkTarget && rel === NEW_TAB_REL) {
				updatedRel = undefined;
			}

			setAttributes({
				linkTarget: newLinkTarget,
				rel: updatedRel,
			});
		},
		[rel, setAttributes],
	);
	const linkControl = (isURLPickerOpen || urlIsSetAndSelected) && (
		<Popover
			position="bottom center"
			onClose={() => setIsURLPickerOpen(false)}
			anchorRef={anchorRef?.current}
		>
			<LinkControl
				className="wp-block-navigation-link__inline-link-input"
				value={{ url, opensInNewTab }}
				onChange={({ url: newURL = '', opensInNewTab: newOpensInNewTab }) => {
					setAttributes({ url: newURL });

					if (opensInNewTab !== newOpensInNewTab) {
						onToggleOpenInNewTab(newOpensInNewTab);
					}
				}}
			/>
		</Popover>
	);
	return (
		<Fragment>
			<BlockControls>
				<ToolbarGroup>
					{!urlIsSet && (
						<ToolbarButton
							name="link"
							icon={link}
							title={__('Link')}
							shortcut={displayShortcut.primary('k')}
							onClick={openLinkControl}
						/>
					)}
					{urlIsSetAndSelected && (
						<ToolbarButton
							name="link"
							icon={linkOff}
							title={__('Unlink')}
							shortcut={displayShortcut.primaryShift('k')}
							onClick={unlinkButton}
							isActive
						/>
					)}
				</ToolbarGroup>
			</BlockControls>
			{isSelected && (
				<KeyboardShortcuts
					bindGlobal
					shortcuts={{
						[rawShortcut.primary('k')]: openLinkControl,
						[rawShortcut.primaryShift('k')]: unlinkButton,
					}}
				/>
			)}
			{linkControl}
		</Fragment>
	);
};

URLPicker.propTypes = {
	url: PropTypes.string,
	rel: PropTypes.string,
	isSelected: PropTypes.bool.isRequired,
	opensInNewTab: PropTypes.bool.isRequired,
	setAttributes: PropTypes.func.isRequired,
	anchorRef: PropTypes.object.isRequired,
};

URLPicker.defaultProps = {
	url: '',
	rel: '',
};
export default URLPicker;
