/**
 * External dependencies
 */
import PropTypes from 'prop-types';

/**
 * WordPress dependencies
 */
import { createBlock } from '@wordpress/blocks';
import { Button } from '@wordpress/components';
import { useSelect, useDispatch } from '@wordpress/data';

/**
 * SingleBlockAppender.
 *
 * This provides a Button component that when clicked inserts a single block type.
 *
 * @param {string} buttonText   The test to display in the button.
 * @param {string} clientId     The clientID of the block associated with the InnerBlocks instance this is being used on.
 * @param {string }allowedBlock The slug of the block that is allowed to be inserted.
 * @param {Object} [props]      Optional. Any additional props passed will be applied to the Button component. ie. isDefault, isLarge
 */

const SingleBlockAppender = ({ buttonText, clientID, allowedBlock, ...props }) => {
	const innerBlocks = useSelect(
		(select) => select('core/block-editor').getBlock(clientID).innerBlocks,
	);
	const { insertBlock } = useDispatch('core/block-editor');

	return (
		<Button
			// eslint-disable-next-line react/jsx-props-no-spreading
			{...props}
			onClick={() => {
				const newBlock = createBlock(allowedBlock);
				insertBlock(newBlock, innerBlocks.length, clientID);
			}}
		>
			{buttonText}
		</Button>
	);
};

SingleBlockAppender.propTypes = {
	buttonText: PropTypes.string.isRequired,
	clientID: PropTypes.string.isRequired,
	allowedBlock: PropTypes.string.isRequired,
};

export default SingleBlockAppender;
