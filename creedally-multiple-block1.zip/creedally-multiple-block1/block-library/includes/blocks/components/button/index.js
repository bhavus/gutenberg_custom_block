/* eslint-disable react/jsx-props-no-spreading */
import PropTypes from 'prop-types';

/**
 * WordPress dependencies
 */
import { __ } from '@wordpress/i18n';
import { RichText } from '@wordpress/block-editor';

/**
 * Button Component.
 *
 * This component displays text and runs an update function that are both passed as props.
 *
 * @param {Object} props            All props sent to this component.
 * @param {string} props.text       The value that gets passed to the rich text component
 * @param {Function} props.onChange Callback for the change event
 * @param {Function} props.onFocus  Callback for the focus event
 * @return {*} Markup for Button.
 */
const Button = ({ text, onChange, onFocus }) => {
	return (
		<div className="wp-block-button">
			<RichText
				tagName="span"
				className="wp-block-button__link"
				placeholder={__('Button text…', '10up-gutenberg-library')}
				value={text}
				allowedFormats={[]}
				onChange={onChange}
				unstableOnFocus={onFocus}
			/>
		</div>
	);
};

Button.propTypes = {
	text: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	onFocus: PropTypes.func,
};

Button.defaultProps = {
	text: '',
	onFocus: () => null,
};

export default Button;
