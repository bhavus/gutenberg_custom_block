import { applyFilters } from '@wordpress/hooks';
import { tns } from 'tiny-slider/src/tiny-slider';

if (!window.tenupBlockLibrary) {
	window.tenupBlockLibrary = {};
}

window.tenupBlockLibrary.contentSliders = [];

const sliders = document.querySelectorAll('.content-slider');

if (sliders.length) {
	sliders.forEach((slider) => {
		const sliderInstance = tns(
			applyFilters('tenup.contentSlider.tnsSettings', {
				container: slider.querySelector('.content-slider-inner'),
				items: parseInt(slider.getAttribute('data-slides-per-page'), 10),
				controlsPosition: 'bottom',
				navPosition: 'bottom',
			}),
		);

		window.tenupBlockLibrary.contentSliders.push({
			slider: sliderInstance,
			node: slider,
		});
	});
}
