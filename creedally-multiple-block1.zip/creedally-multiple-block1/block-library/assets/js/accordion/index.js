import Accordion from '@10up/component-accordion';

// eslint-disable-next-line no-new
new Accordion('.accordion');
