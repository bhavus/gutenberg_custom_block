<?php
/**
 * Plugin Name:       10up Block Library
 * Plugin URI:        https://github.com/10up/block-library
 * Description:       Finely crafted blocks made by 10up.
 * Version:           1.0.3
 * Requires at least: 5.6
 * Requires PHP:      7.0
 * Author:            10up
 * Author URI:        https://10up.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       10up-block-library
 * Domain Path:       /languages
 * Update URI:        https://github.com/10up/block-library
 *
 * @package 10up-block-library
 */

// Useful global constants.
define( 'TENUP_BLOCK_LIBRARY_VERSION', '1.0.3' );
define( 'TENUP_BLOCK_LIBRARY_URL', plugin_dir_url( __FILE__ ) );
define( 'TENUP_BLOCK_LIBRARY_PATH', plugin_dir_path( __FILE__ ) );
define( 'TENUP_BLOCK_LIBRARY_INC', TENUP_BLOCK_LIBRARY_PATH . 'includes/' );
define( 'TENUP_BLOCK_LIBRARY_SRC', TENUP_BLOCK_LIBRARY_INC . 'blocks/' );
define( 'TENUP_BLOCK_LIBRARY_DIST', TENUP_BLOCK_LIBRARY_URL . 'dist/' );
define( 'TENUP_BLOCK_LIBRARY_BLOCK_SRC', TENUP_BLOCK_LIBRARY_SRC . 'block-editor/blocks' );

// Require Composer autoloader if it exists.
if ( file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
	require_once __DIR__ . '/vendor/autoload.php';
} else {
	require_once __DIR__ . '/vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';

	/**
	 * PSR-4 autoloading
	 */
	spl_autoload_register(
		function( $class ) {
				// Project-specific namespace prefix.
				$prefix = 'TenupBlockLibrary\\';
				// Base directory for the namespace prefix.
				$base_dir = __DIR__ . '/includes/classes/';
				// Does the class use the namespace prefix?
				$len = strlen( $prefix );
			if ( strncmp( $prefix, $class, $len ) !== 0 ) {
				return;
			}
				$relative_class = substr( $class, $len );
				$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';
				// If the file exists, require it.
			if ( file_exists( $file ) ) {
				require $file;
			}
		}
	);
}

if ( class_exists( 'Puc_v4_Factory' ) ) {
	// @codingStandardsIgnoreStart
	$updateChecker = Puc_v4_Factory::buildUpdateChecker(
		'https://github.com/10up/block-library/',
		__FILE__,
		'10up-block-library'
	);

	$updateChecker->setAuthentication( '4dac3a5e640ee516061d04b9b8a2f11aeb8c1ded' );
	// @codingStandardsIgnoreEnd
}

// Bootstrap.
TenupBlockLibrary\Core\TextDomain::get_instance()->setup();
// Block Editor
TenupBlockLibrary\BlockEditor\Categories::get_instance()->setup();

// Load the combined assets for WordPress installs that are pre 5.5 and are not using the latest Gutenberg plugin.
if ( ! function_exists( 'register_block_type_from_metadata' ) ) {
	TenupBlockLibrary\BlockEditor\Assets::get_instance()->setup();
}

// Blocks.
TenupBlockLibrary\Blocks\Registry::get_instance()->setup();

// Block Conteext
TenupBlockLibrary\Blocks\BlockContext\Tabs::get_instance()->setup();
