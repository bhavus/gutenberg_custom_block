import { InnerBlocks } from '@wordpress/block-editor';

const HeroBlockSave = () => <InnerBlocks.Content />;

export default HeroBlockSave;
