<?php

//function rpssrb_render_callback( $attributes ) {
    $attributes = shortcode_atts(
        [
            'post_type'      => 'post',
            'orderby'        => 'rand',
            'posts_per_page' => 5,
        ],
        $attributes
    );

    $query = new WP_Query( $attributes );

    $output = '';
    if ( $query->have_posts() ) {
        $output .= '<ul>';
        while ( $query->have_posts() ) {
            $query->the_post();
            $output .= sprintf(
        '<li><a href=%s>%s</a></li>',
                get_permalink(),
                get_the_title()
            );
        }
        $output .= '</ul>';
    }

    echo $output;

//}
//add_shortcode( 'rpssrb_random_posts', 'rpssrb_render_callback' );
//echo do_shortcode( '[rpssrb_random_posts]' );


