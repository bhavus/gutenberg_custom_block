
import { __ } from '@wordpress/i18n';
import {
    ToggleControl,
    PanelBody,
    PanelRow,
    CheckboxControl,
    SelectControl,
    ColorPicker,
    RangeControl,
    Disabled,

} from '@wordpress/components';
import {
    RichText,
    InspectorControls,
    BlockControls,
    AlignmentToolbar,

} from '@wordpress/block-editor';

import ServerSideRender from '@wordpress/server-side-render';

import { useBlockProps } from '@wordpress/block-editor';

import './editor.css';

const postrendomBockEdit = ( props ) => {
    
    const { attributes, setAttributes } = props;

    const blockProps = useBlockProps();

    const { postsToShow } = attributes;
    return (
        <>

            <div { ...useBlockProps() }>

                    <ServerSideRender
                        block="pms/random-posts"
                        attributes={ attributes }
                    />

            </div>
        </>
    );
    // return wp.element.createElement(
    //     wp.serverSideRender,
    //     {
    //        block: 'pms/random-posts'
    //     }
    //
    // );

};
export default postrendomBockEdit;


