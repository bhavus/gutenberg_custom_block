const { RichText } = wp.blockEditor;


const postrendomBockSave = ( props ) => {
    const { attributes } = props;
    const alignmentClass = (attributes.textAlignment != null) ? 'has-text-align-' + attributes.textAlignment : '';
    return (
        <div className={alignmentClass}>
            <RichText.Content
                tagName="h2"
                value={attributes.myRichHeading}
            />
            <RichText.Content
                tagName="p"
                value={attributes.myRichText}
            />
            {attributes.activateLasers &&
                <div className="lasers">Lasers activated</div>
            }

        </div>
    );
};
export default postrendomBockSave;