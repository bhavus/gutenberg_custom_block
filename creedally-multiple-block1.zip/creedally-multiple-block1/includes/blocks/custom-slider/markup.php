<?php
print_r($attributes);
print_r($content);
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_script(
        'cycle2-slider-js',
        get_template_directory_uri() . '/assets/js/jquery.cycle2.min.js',
        ['jquery'],
        '',
        true
    );
});


//

if (empty($attributes['termId'])) {
    return '';
}

$postQuery = new WP_Query([
    'posts_per_page' => $attributes['numSlides'],
    'cat' => $attributes['termId']
]);

if ($postQuery->have_posts()) {
    $output = '<div class="wp-block-awp-slider align' . $attributes['align'] . '">';
    $output .= '<div class="cycle-slideshow" data-cycle-timeout=4000>';
    while ($postQuery->have_posts()) {
        $postQuery->the_post();

        if (has_post_thumbnail()) {
            $img_url = get_the_post_thumbnail_url(get_the_ID(), 'loop-thumbnail');
            $output .= '<img src="' . $img_url . '" />';
        }
    }
    wp_reset_postdata();
    $output .= '</div>';
    $output .= '</div>';

    return $output;

} else {
    return '';
}





