import { __ } from '@wordpress/i18n';


// Importing the block's editor styles via JS will enable hot reloading for css
import './editor.css';
import CategorySelect from './awp-category-picker';



const { InspectorControls } = wp.blockEditor;
const { Placeholder, PanelBody, RangeControl } = wp.components;


const sliderBockEdit = ( props ) => {
    const { attributes, setAttributes } = props;
    const selectTerm = (termId) => {
        setAttributes({ termId: termId });
    }

    return(
        <div className={props.className}>
            <InspectorControls>
                <PanelBody title={__('Slider Settings', 'pms')} initialOpen={true} >
                    <RangeControl
                        label={__('Number of slides', 'pms')}
                        value={attributes.numSlides}
                        onChange={(val) => setAttributes({ numSlides: val })}
                        min={1}
                        max={10}
                    />
                </PanelBody>
            </InspectorControls>
            <Placeholder label={__('Slider Category', 'awp')} >
                <CategorySelect
                    selectedTermId={attributes.termId}
                    selectTerm={selectTerm}
                />
            </Placeholder>
        </div>
    );
};
export default sliderBockEdit;