const sliderBlockSave = () => null;

export default sliderBlockSave;
