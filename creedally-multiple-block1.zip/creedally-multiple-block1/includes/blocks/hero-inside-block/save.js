import { InnerBlocks } from '@wordpress/block-editor';

const HeroInsideBockSave = () => <InnerBlocks.Content />;

export default HeroInsideBockSave;
