/**
 * Example-block
 * Custom title block -- feel free to delete
 */

/**
 * WordPress dependencies
 */
import { registerBlockType } from '@wordpress/blocks';
import { postAuthor as icon } from '@wordpress/icons';



 /**
  * Internal dependencies
  */
 //import initBlock from '../utils/init-block';

 import block from './block.json';
 import edit from './edit';
 import save from './save';

// const { name } = block;
// export { block, name };
//
// export const settings = {
//     icon,
//     edit,
//
// };
//
// export const init = () => initBlock( { name, block, settings } );

/**
 * Register block
 */
registerBlockType( block, {
   edit,
   save,
} );



 
