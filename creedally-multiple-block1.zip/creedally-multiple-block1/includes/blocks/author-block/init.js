/**
 * Internal dependencies
 */
import { init } from './';

export default init();
