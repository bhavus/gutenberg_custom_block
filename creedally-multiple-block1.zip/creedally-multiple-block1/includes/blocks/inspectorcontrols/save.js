/**
 * See https://wordpress.org/gutenberg/handbook/designers-developers/developers/block-api/block-edit-save/#save
 *
 * @return {null} Dynamic blocks do not save the HTML.
 */
import {  useBlockProps } from '@wordpress/block-editor';
export default function save( { attributes } ) {
    const { blockBackground, blockColor, blockText } = attributes;
    return (
        <p
            { ...useBlockProps.save() }
            style={ {
                backgroundColor: blockBackground,
                color: blockColor,
            } }
        >
            { blockText }
        </p>
    );
}
