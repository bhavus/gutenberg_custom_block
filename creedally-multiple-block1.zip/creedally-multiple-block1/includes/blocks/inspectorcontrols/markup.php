<?php
/**
 * Example block markup
 *
 * @package EverbridgeTheme\Blocks\Example
 *
 * @var array    $attributes         Block attributes.
 * @var string   $content            Block content.
 * @var WP_Block $block              Block instance.
 * @var array    $context            BLock context.
 */
//echo "<pre>";
//print_r($attributes);

?>

<div <?php echo get_block_wrapper_attributes(); // phpcs:ignore //wp-block-pms-example ?>>

    <h2 class="wp-block-inspectorcontrols__content" style="background-color: <?php echo wp_kses_post( $attributes['blockBackground'] ); ?>">
        <span style="color: <?php echo wp_kses_post( $attributes['blockColor'] ); ?>"> <?php echo wp_kses_post( $attributes['blockText'] ); ?></span>
    </h2>
</div>


