const PostPickerItemBlockSave = () => null;

export default PostPickerItemBlockSave;
