<?php
/**
 * Post picker block.
 *
 * @package EverbridgeTheme\Blocks\post-picker
 *
 * @var array    $attributes         Block attributes.
 * @var string   $content            Block content.
 * @var WP_Block $block              Block instance.
 * @var array    $context            BLock context.
 */

$selected_post = ! empty( $attributes['selected_post']['id'] ) ? esc_html( $attributes['selected_post']['id'] ) : '';

if ( empty( $selected_post ) ) {
	return;
}

if ( 'publish' !== get_post_status( $selected_post ) ) {
	return;
}

$selected_taxonomy  = ! empty( $attributes['selected_taxonomy'] ) ? esc_html( $attributes['selected_taxonomy'] ) : '';
$selected_post_type = ! empty( $attributes['selected_post_type'] ) ? esc_html( $attributes['selected_post_type'] ) : '';
$hide_overline      = ! empty( $attributes['hide_overline'] ) ? esc_html( $attributes['hide_overline'] ) : '';
$hide_image         = ! empty( $attributes['hide_image'] ) ? esc_html( $attributes['hide_image'] ) : '';
$hide_headline      = ! empty( $attributes['hide_headline'] ) ? esc_html( $attributes['hide_headline'] ) : '';
$hide_excerpt       = ! empty( $attributes['hide_excerpt'] ) ? esc_html( $attributes['hide_excerpt'] ) : '';
$hide_link          = ! empty( $attributes['hide_link'] ) ? esc_html( $attributes['hide_link'] ) : '';

$thumbnail_url = get_the_post_thumbnail_url( $selected_post, 'post-thumbnail' );

if ( empty( $selected_post ) || empty( $selected_taxonomy ) ) {
		return;
  }
else{
	$terms = get_the_terms( $selected_taxonomy, $selected_taxonomy );
    $term_title = ! empty( $terms[0]->name ) ? esc_html( $terms[0]->name ) : '';
   }
/**
 * Get post extra meta fields.
 *
 * @param int $post_id Get Post id.
 * @return mixed|void $external_meta
 */

//$external_meta = get_post_external_meta( $selected_post );



	if ( empty( $selected_post ) ) {
		// return;
		echo $external_meta =  $selected_post;
	}
else{
	$external_meta = array();
	$post_type     = get_post_type( $selected_post );
	$post_excerpt  = get_the_excerpt( $selected_post );

	$get_permalink = get_the_permalink( $selected_post );

	$default_text = esc_attr__( 'read more', 'pms' );

	switch ( $post_type ) {
		case 'news_item':
			$news_fields                   = get_post_meta( $post_id, 'news_fields', true );
			$external_meta['is_summary']   = false;
			$external_meta['description']  = ! empty( $post_excerpt ) ? esc_html( $post_excerpt ) : '';
			$external_meta['external_url'] = ! empty( $news_fields['external_url'] ) ? esc_url( $news_fields['external_url'] ) : esc_url( $get_permalink );
			$external_meta['link_text']    = ! empty( $news_fields['link_text'] ) ? esc_html( $news_fields['link_text'] ) : esc_html( $default_text );
			break;
		case 'resource':
			$resource_fields               = get_post_meta( $post_id, 'resource_fields', true );
			$external_meta['is_summary']   = ! empty( $resource_fields['summary'] ) ? true : false;
			$external_meta['description']  = ! empty( $resource_fields['summary'] ) ? esc_html( $resource_fields['summary'] ) : esc_html( $post_excerpt );
			$external_meta['external_url'] = ! empty( $resource_fields['external_url'] ) ? esc_url( $resource_fields['external_url'] ) : esc_url( $get_permalink );
			$external_meta['link_text']    = ! empty( $resource_fields['link_text'] ) ? esc_html( $resource_fields['link_text'] ) : esc_html( $default_text );
			break;
		default:
			$external_meta['is_summary']   = false;
			$external_meta['description']  = esc_html( $post_excerpt );
			$external_meta['external_url'] = get_the_permalink( $selected_post );
			$external_meta['link_text']    = esc_html( $default_text );
	}
	echo $external_meta =  $selected_post;
	//return apply_filters( '10up_eb_post_external_meta', $external_meta, $selected_post );
  }

// end

$summary = '';
if ( empty( $hide_excerpt ) ) {
	$summary = ! empty( $external_meta['description'] ) ? esc_html( $external_meta['description'] ) : '';
}

$link_text = ! empty( $external_meta['link_text'] ) ? esc_html( $external_meta['link_text'] ) : '';
$url       = ! empty( $external_meta['external_url'] ) ? esc_url( $external_meta['external_url'] ) : '';

$is_sub_heading = false;
if ( ! empty( $hide_overline ) || empty( $term_title ) ) {
	$is_sub_heading = true;
}
?>
<div <?php echo get_block_wrapper_attributes(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
<div class="post-item-wrap">
	<article <?php post_class( '', $selected_post ); ?> id="post-<?php echo esc_html( $selected_post ); ?>">
		<?php if ( empty( $hide_overline ) && ! empty( $term_title ) ) { ?>
			<h6 class="sub-heading"><?php echo esc_html( $term_title ); ?></h6>
		<?php } ?>

		<div class="post-content <?php echo ! empty( $is_sub_heading ) ? 'no-sub-heading' : ''; ?>">
			<?php if ( empty( $hide_image ) && ! empty( $thumbnail_url ) ) { ?>
				<div class="image-wrap">
					<img src="<?php echo esc_url( $thumbnail_url ); ?>" alt="<?php echo esc_html( get_the_title( $selected_post ) ); ?>"/>
				</div>
			<?php } ?>

			<?php if ( empty( $hide_headline ) ) { ?>
				<h3 class="featured-title"><?php echo esc_html( get_the_title( $selected_post ) ); ?></h3>
			<?php } ?>

				<div class="featured-content"><!-- start -->
					<?php  if ( empty( $text ) && empty( $hide_text ) ) {
				        $text = get_the_excerpt();
				    }

				    if ( empty( $read_more_label ) ) {
				        $read_more_label = __( 'read more', 'pms' );
				    }
				    if ( empty( $read_more_url ) ) {
				        $read_more_url = get_permalink();
				    }

				    $lines = explode( "\n", $text );
				    $count = count( $lines );

				    if ( empty( $hide_more ) ) {
				        $lines[ $count - 1 ] .= '<p><a target="' . esc_attr( $read_more_target ) . '" class="read-more" href="' . esc_url( $read_more_url ) . '">' . esc_html( $read_more_label ) . '</a></p>';
				    }

				    echo wpautop( join( "\n", $lines ) ); ?>
			</div>
		</div>
	</article>
</div>
</div>
