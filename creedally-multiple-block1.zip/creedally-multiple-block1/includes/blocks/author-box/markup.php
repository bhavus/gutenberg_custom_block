<?php
/**
 * Example block markup
 *
 * @package EverbridgeTheme\Blocks\Example
 *
 * @var array    $attributes         Block attributes.
 * @var string   $content            Block content.
 * @var WP_Block $block              Block instance.
 * @var array    $context            BLock context.
 */

?>

<?php

    $args = array(
        'numberposts'	=> $attributes['numberOfItems']
    );
    $my_posts = get_posts( $args );

    if( ! empty( $my_posts ) ){
        $output = '<div ' . get_block_wrapper_attributes() . '>';

        if( $attributes['displayAuthorInfo'] ){
            $output .= '<div class="wp-block-author-box-author-plugin__author">';

            if( $attributes['showAvatar'] ){
                $output .= '<div class="wp-block-author-box-author-plugin__avatar">'
                    . get_avatar( get_the_author_meta( 'ID' ), $attributes['avatarSize'] )
                    . '</div>';
            }

            $output .= '<div class="wp-block-author-box-author-plugin__author-content">';

            $output .= '<div class="wp-block-author-box-author-plugin__name">'
                . get_the_author_meta( 'display_name' )
                . '</div>';

            if( $attributes['showBio'] ){
                $output .= '<div class="wp-block-author-box-author-plugin__description">'
                    . get_the_author_meta( 'description' )
                    . '</div>';
            }

            $output .= '</div>';
            $output .= '</div>';
        }

        $num_cols = $attributes['columns'] > 1 ? strval( $attributes['columns'] ) : '1';

        $output .= '<ul class="wp-block-author-box-author-plugin__post-items columns-' . $num_cols . '">';
        foreach ( $my_posts as $p ){

            $title = $p->post_title ? $p->post_title : 'Default title';
            $url = esc_url( get_permalink( $p->ID ) );
            $thumbnail = has_post_thumbnail( $p->ID ) ? get_the_post_thumbnail( $p->ID, 'large', array( 'class' => 'wp-block-author-box-author-plugin__post-thumbnail' ) ) : '';

            $output .= '<li>';
            if( ! empty( $thumbnail ) && $attributes['displayThumbnail'] ){
                $output .= $thumbnail;
            }
            $output .= '<h5 class="wp-block-author-box-author-plugin__post-title"><a href="' . $url . '">' . $title . '</a></h5>';
            if( $attributes['displayDate'] ){
                $output .= '<time datetime="' . esc_attr( get_the_date( 'c', $p ) ) . '" class="wp-block-author-box-author-plugin__post-date">' . esc_html( get_the_date( '', $p ) ) . '</time>';
            }
            if( get_the_excerpt( $p ) && $attributes['displayExcerpt'] ){
                $output .= '<div class="wp-block-author-box-author-plugin__post-excerpt">' . get_the_excerpt( $p ) . '</div>';
            }
            $output .= '</li>';
        }
        $output .= '</ul>';
        $output .= '</div>';
    }
    echo  $output ?? '<strong>Sorry. No posts matching your criteria!</strong>';

?>
