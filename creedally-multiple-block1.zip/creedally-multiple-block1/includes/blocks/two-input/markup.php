<?php

    // Extract whatever block attribute data we need.
    $myRichHeading = $attributes['myRichHeading'] ?? '';
    $myRichText = $attributes['myRichText'] ?? '';
    $favoriteColor = $attributes['favoriteColor'] ?? '';
    $activateLasers = $attributes['activateLasers'] ?? '';
    $toggle = $attributes['toggle'] ?? '';
    $favoriteAnimal = $attributes['favoriteAnimal'] ?? '';


    // Create and return the front-end markup. I find it easier
    // to use a heredoc for readability purposes.
    ?>
<table>
<dl>
    <dt><?php  echo $myRichHeading; ?></dt>
    <dd><?php echo $myRichText; ?></dd>
  </dl>
</table>

