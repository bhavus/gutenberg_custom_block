


import {
    ToggleControl,
    PanelBody,
    PanelRow,
    CheckboxControl,
    SelectControl,
    ColorPicker,

} from '@wordpress/components';
import {
    RichText,
    InspectorControls,
    BlockControls,
    AlignmentToolbar,

} from '@wordpress/block-editor';



import './editor.css';

const wordBockEdit = ( props ) => {

        const { attributes, setAttributes } = props;

       const alignmentClass = (attributes.textAlignment != null) ? 'has-text-align-' + attributes.textAlignment : '';
        return (
            <div className={alignmentClass}>
                <InspectorControls>
                    <PanelBody
                        title="Most awesome settings ever"
                        initialOpen={true}
                    >
                        <PanelRow>
                            <ToggleControl
                                label="Toggle me"
                                checked={attributes.toggle}
                                onChange={(newval) => setAttributes({ toggle: newval })}
                            />
                        </PanelRow>
                        <PanelRow>
                            <SelectControl
                                label="What's your favorite animal?"
                                value={attributes.favoriteAnimal}
                                options={[
                                    {label: "Dogs", value: 'dogs'},
                                    {label: "Cats", value: 'cats'},
                                    {label: "Something else", value: 'weird_one'},
                                ]}
                                onChange={(newval) => setAttributes({ favoriteAnimal: newval })}
                            />
                        </PanelRow>
                        <PanelRow>
                            <ColorPicker
                                color={attributes.favoriteColor}
                                onChangeComplete={(newval) => setAttributes({ favoriteColor: newval.hex })}
                                disableAlpha
                            />
                        </PanelRow>
                        <PanelRow>
                            <CheckboxControl
                                label="Activate lasers?"
                                checked={attributes.activateLasers}
                                onChange={(newval) => setAttributes({ activateLasers: newval })}
                            />
                        </PanelRow>
                    </PanelBody>
                </InspectorControls>


                <BlockControls>
                    <AlignmentToolbar
                        value={attributes.textAlignment}
                        onChange={(newalign) => setAttributes({ textAlignment: newalign })}
                    />
                    <Toolbar>
                        <IconButton
                            label="My very own custom button"
                            icon="edit"
                            className="my-custom-button"
                            onClick={() => console.log('pressed button')}
                        />
                    </Toolbar>
                </BlockControls>
                <RichText
                    tagName="h2"
                    placeholder="Write your heading here"
                    value={attributes.myRichHeading}
                    onChange={(newtext) => setAttributes({ myRichHeading: newtext })}
                />
                <RichText
                    tagName="p"
                    placeholder="Write your paragraph here"
                    value={attributes.myRichText}
                    onChange={(newtext) => setAttributes({ myRichText: newtext })}
                />

            </div>
        );
    };
export default wordBockEdit;


