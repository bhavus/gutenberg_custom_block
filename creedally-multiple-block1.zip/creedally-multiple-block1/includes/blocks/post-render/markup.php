<?php
   $args = [
        'post_type'      => 'post',
        'post_status' => 'publish',
        'orderby'        => 'rand',
        'posts_per_page' => (int) $attributes['postsToShow'],
    ];
    $my_posts = get_posts($args);
    foreach( $my_posts as $keys ) {
         echo $keys->ID."<br>";
         echo "<h3>".$keys->post_title."</h3>"."<br>";
         echo $keys->post_content."<br>";
    }
    ?>
