const { RichText } = wp.blockEditor;


const postBlockSave = ( props ) => {

};
export default postBlockSave;