

import { __ } from '@wordpress/i18n';
import {
    ToggleControl,
    PanelBody,
    PanelRow,
    CheckboxControl,
    SelectControl,
    ColorPicker,
    RangeControl,
    Disabled,

} from '@wordpress/components';
import {
    RichText,
    InspectorControls,
    BlockControls,
    AlignmentToolbar,

} from '@wordpress/block-editor';

import ServerSideRender from '@wordpress/server-side-render';

import { useBlockProps } from '@wordpress/block-editor';

import './editor.css';

const postBockEdit = ( props ) => {
    
    const { attributes, setAttributes } = props;

    const blockProps = useBlockProps();

    const { postsToShow } = attributes;

        return (
            <>
                <InspectorControls>
                    <PanelBody
                        title={ __( 'Settings', 'pms' ) }
                    >
                        <RangeControl
                            label={ __( 'Number of items', 'pms' ) }
                            value={ postsToShow }
                            onChange={ ( value ) =>
                                setAttributes( { postsToShow: value } )
                            }
                            min="1"
                            max="100"
                        />
                    </PanelBody>
                </InspectorControls>
                <div { ...useBlockProps() }>
                    <Disabled>
                        <ServerSideRender
                            block="pms/post-render"
                            attributes={ attributes }
                        />
                    </Disabled>
                </div>
            </>
        );

};
export default postBockEdit;


