<?php
add_action( 'init', function () {

    register_post_type( 'project',  array(
        'labels'             => array(
            'name'                  => __( 'Projects', 'pms' ),
            'singular_name'         => __( 'Project', 'pms' ),
            'menu_name'             => __( 'Projects', 'pms' ),
            'name_admin_bar'        => __( 'Project', 'pms' ),
            'add_new'               => __( 'Add New', 'pms' ),
            'add_new_item'          => __( 'Add New Project', 'pms' ),
            'new_item'              => __( 'New Project', 'pms' ),
            'edit_item'             => __( 'Edit Project', 'pms' ),
            'view_item'             => __( 'View Project', 'pms' ),
            'all_items'             => __( 'All Projects', 'pms' ),
            'search_items'          => __( 'Search Projects', 'pms' ),
            'parent_item_colon'     => __( 'Parent Projects:', 'pms' ),
            'not_found'             => __( 'No Projects found.', 'pms' ),
            'not_found_in_trash'    => __( 'No Projects found in Trash.', 'pms' ),
            'featured_image'        => __( 'Project Image', 'pms' ),
            'set_featured_image'    => __( 'Set Project image', 'pms' ),
            'remove_featured_image' => __( 'Remove Project image', 'pms' ),
            'use_featured_image'    => __( 'Use as Project image', 'pms' ),
            'archives'              => __( 'Project archives', 'pms' ),
            'filter_items_list'     => __( 'Filter Projects list', 'pms' ),
            'items_list_navigation' => __( 'Projects list navigation', 'pms' ),
            'items_list'            => __( 'Projects list', 'pms' ),
        ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array(
            'with_front' => false,
            'slug'       => 'project',
        ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'           => 'dashicons-text-page',
        'show_in_rest'       => true,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'can_export'          => true,
    ) );

    register_post_type( 'tasks',  array(
        'labels'             => array(
            'name'                  => __( 'Tasks', 'pms' ),
            'singular_name'         => __( 'Task', 'pms' ),
            'menu_name'             => __( 'Tasks', 'pms' ),
            'name_admin_bar'        => __( 'Task', 'pms' ),
            'add_new'               => __( 'Add New', 'pms' ),
            'add_new_item'          => __( 'Add New Task', 'pms' ),
            'new_item'              => __( 'New Task', 'pms' ),
            'edit_item'             => __( 'Edit Task', 'pms' ),
            'view_item'             => __( 'View Task', 'pms' ),
            'all_items'             => __( 'All Tasks', 'pms' ),
            'search_items'          => __( 'Search Tasks', 'pms' ),
            'parent_item_colon'     => __( 'Parent Tasks:', 'pms' ),
            'not_found'             => __( 'No Tasks found.', 'pms' ),
            'not_found_in_trash'    => __( 'No Tasks found in Trash.', 'pms' ),
            'featured_image'        => __( 'Task Image', 'pms' ),
            'set_featured_image'    => __( 'Set Task image', 'pms' ),
            'remove_featured_image' => __( 'Remove Task image', 'pms' ),
            'use_featured_image'    => __( 'Use as Task image', 'pms' ),
            'archives'              => __( 'Task archives', 'pms' ),
            'filter_items_list'     => __( 'Filter Tasks list', 'pms' ),
            'items_list_navigation' => __( 'Tasks list navigation', 'pms' ),
            'items_list'            => __( 'Tasks list', 'pms' ),
        ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array(
            'with_front' => false,
            'slug'       => 'tasks',
        ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'           => 'dashicons-list-view',
        'show_in_rest'       => true,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'can_export'          => true,
    ) );
});

add_action( 'init', function () {

    register_taxonomy( 'project_category', array( 'project' ), array(
        'hierarchical'      => true,
        'labels'            => array(
            'name'              => __( 'Category', 'pms' ),
            'singular_name'     => __( 'Category', 'pms' ),
            'search_items'      => __( 'Search Category', 'pms' ),
            'all_items'         => __( 'All Category', 'pms' ),
            'parent_item'       => __( 'Parent Category', 'pms' ),
            'parent_item_colon' => __( 'Parent Category:', 'pms' ),
            'edit_item'         => __( 'Edit Category', 'pms' ),
            'update_item'       => __( 'Update Category', 'pms' ),
            'add_new_item'      => __( 'Add New Category', 'pms' ),
            'new_item_name'     => __( 'New Category Name', 'pms' ),
            'menu_name'         => __( 'Category', 'pms' ),
        ),
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'show_in_rest'      => true,
        'rewrite'           => array(
            'with_front' => false,
            'slug'       => 'project_category',
        ),
    ) );

    register_taxonomy( 'task_status', array( 'tasks' ), array(
        'hierarchical'      => true,
        'labels'            => array(
            'name'              => __( 'Status', 'pms' ),
            'singular_name'     => __( 'Status', 'pms' ),
            'search_items'      => __( 'Search Status', 'pms' ),
            'all_items'         => __( 'All Status', 'pms' ),
            'parent_item'       => __( 'Parent Status', 'pms' ),
            'parent_item_colon' => __( 'Parent Status:', 'pms' ),
            'edit_item'         => __( 'Edit Status', 'pms' ),
            'update_item'       => __( 'Update Status', 'pms' ),
            'add_new_item'      => __( 'Add New Status', 'pms' ),
            'new_item_name'     => __( 'New Status Name', 'pms' ),
            'menu_name'         => __( 'Status', 'pms' ),
        ),
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'show_in_rest'      => true,
        'rewrite'           => array(
            'with_front' => false,
            'slug'       => 'task_status',
        ),
    ) );

    register_taxonomy( 'task_priority', array( 'tasks' ), array(
        'hierarchical'      => true,
        'labels'            => array(
            'name'              => __( 'Priority', 'pms' ),
            'singular_name'     => __( 'Priority', 'pms' ),
            'search_items'      => __( 'Search Priority', 'pms' ),
            'all_items'         => __( 'All Priority', 'pms' ),
            'parent_item'       => __( 'Parent Priority', 'pms' ),
            'parent_item_colon' => __( 'Parent Priority:', 'pms' ),
            'edit_item'         => __( 'Edit Priority', 'pms' ),
            'update_item'       => __( 'Update Priority', 'pms' ),
            'add_new_item'      => __( 'Add New Priority', 'pms' ),
            'new_item_name'     => __( 'New Priority Name', 'pms' ),
            'menu_name'         => __( 'Priority', 'pms' ),
        ),
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'show_in_rest'      => true,
        'rewrite'           => array(
            'with_front' => false,
            'slug'       => 'task_priority',
        ),
    ) );
});


add_action( 'init', function () {

    $default_terms = array(
        'project_category' => array(
            __('Html','pms'),
            __('CSS','pms'),
            __('javascript','pms'),
            __('jQuery','pms'),
            __('PHP','pms'),
            __('WordPress','pms'),
            __('WooCommerce','pms'),
            __('React','pms'),
            __('Guterburg','pms'),
        ),
        'task_priority' => array(
            __('High','pms'),
            __('Medium','pms'),
            __('Low','pms'),
        ),
        'task_status' => array(
            __('Discovery','pms'),
            __('Ready to Start','pms'),
            __('In Progress','pms'),
            __('Code Review','pms'),
            __('QA','pms'),
            __('QA Remediation','pms'),
            __('UAT','pms'),
            __('UAT Remediation','pms'),
            __('Approved','pms'),
            __('Ready for Deployment','pms'),
            __('Done','pms'),
            __('Blocked','pms'),
            __('Hold','pms'),
        ),
    );

    $default_terms = apply_filters('pms_default_terms', $default_terms);

    if( !empty( $default_terms ) && is_array( $default_terms ) ) {

        foreach ( $default_terms as $taxonomy => $terms ) {

            if( !empty( $terms ) && is_array( $terms ) ) {

                foreach ($terms as $term) {

                    $term_slug = !empty( $term ) ? strtolower( str_replace(' ', '-', $term) ) : '';

                    if( ! term_exists( $term_slug, $taxonomy ) ) {
                        wp_insert_term($term, $taxonomy, array(
                            'slug' => $term_slug,
                        ));
                    }
                }
            }
        }
    }
});