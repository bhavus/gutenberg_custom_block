<?php
//function myplugin_register_book_post_type() {
    add_action( 'init', function () {
    $args = array(
        'public' => true,
        'label'  => 'Books',
        'show_in_rest' => true,
        'template' => array(
            array( 'core/columns', array(), array(
                array( 'core/column', array(), array(
                    array( 'core/image', array() ),
                ) ),
                array( 'core/column', array(), array(
                    array( 'core/paragraph', array(
                        'placeholder' => 'Add a inner paragraph'
                    ) ),
                ) ),
            ) )
        ),
    );
    register_post_type( 'book', $args );
});
//add_action( 'init', 'myplugin_register_book_post_type' );


/**
 * Register custom block template for books.
 */
function example_theme_register_book_post_type() {
    $args = array(
        'public'       => true,
        'label'        => 'Testcpt',
        'show_in_rest' => true,
        'template'     => array(
            array( 'core/pattern', array(
                'slug' => 'pattern/testcpt-block-template',
            ) ),
        ),
		'hierarchical'  => true,
		'supports'      => array( 'title', 'editor', 'page-attributes' ),
    );
    register_post_type( 'testcpt', $args );
}
add_action( 'init', 'example_theme_register_book_post_type' );




