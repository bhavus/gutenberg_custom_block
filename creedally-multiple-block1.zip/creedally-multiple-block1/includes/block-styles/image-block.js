/* Add custom attribute to image block, in Sidebar */

// eslint-disable-next-line import/no-extraneous-dependencies
import classnames from 'classnames';

// Enable custom attributes on Image block
const enableSidebarSelectOnBlocks = ['core/image'];

const { __ } = wp.i18n;
const { createHigherOrderComponent } = wp.compose;
const { Fragment } = wp.element;
const { InspectorControls } = wp.blockEditor;
const { PanelBody, ToggleControl } = wp.components;

const youtubePattern =
	/^(?:https?:\/\/)?(?:m\.|www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;

const setSidebarSelectAttribute = (settings, name) => {
	if (!enableSidebarSelectOnBlocks.includes(name)) {
		return settings;
	}

	return {
		...settings,
		attributes: {
			...settings.attributes,
			popupButtonMode: { type: 'boolean', default: false },
		},
	};
};
wp.hooks.addFilter(
	'blocks.registerBlockType',
	'custom-attributes/set-sidebar-select-attribute',
	setSidebarSelectAttribute,
);

const withSidebarSelect = createHigherOrderComponent((BlockEdit) => {
	return (props) => {
		// eslint-disable-next-line react/destructuring-assignment
		if (!enableSidebarSelectOnBlocks.includes(props.name)) {
			return <BlockEdit {...props} />;
		}

		const { attributes, setAttributes } = props;
		const { popupButtonMode, href } = attributes;

		if (href !== null && href !== undefined) {
			const match = href.match(youtubePattern);

			if (match && match[1].length > 0) {
				return (
					<Fragment>
						<BlockEdit {...props} />
						<InspectorControls>
							<PanelBody title={__('Image Custom Attributes', 'everbridge-theme')}>
								<ToggleControl
									label={__('Dark Mode', 'everbridge-theme')}
									checked={popupButtonMode || ''}
									onChange={(value) => {
										setAttributes({ popupButtonMode: value });
									}}
								/>
							</PanelBody>
						</InspectorControls>
					</Fragment>
				);
			}
		}

		return <BlockEdit {...props} />;
	};
}, 'withSidebarSelect');

wp.hooks.addFilter('editor.BlockEdit', 'custom-attributes/with-sidebar-select', withSidebarSelect);

/**
 * Add has-image-video-popup class to block in Edit
 */
const withSidebarSelectProp = createHigherOrderComponent((BlockListBlock) => {
	return (props) => {
		// If current block is not allowed
		// eslint-disable-next-line react/destructuring-assignment
		if (!enableSidebarSelectOnBlocks.includes(props.name)) {
			return <BlockListBlock {...props} />;
		}

		const { attributes } = props;
		const { href, popupButtonMode } = attributes;

		let popupClass = '';

		if (href !== null && href !== undefined) {
			const match = href.match(youtubePattern);

			if (match && match[1].length > 0) {
				popupClass += ' has-youtube-embed has-image-popup';

				if (popupButtonMode) {
					popupClass += ' has-dark-mode';
				}
			}
		}

		return <BlockListBlock {...props} className={popupClass} />;
	};
}, 'withSidebarSelectProp');

wp.hooks.addFilter(
	'editor.BlockListBlock',
	'custom-attributes/with-sidebar-select-prop',
	withSidebarSelectProp,
);

/**
 * Save popup custom settings for image block.
 *
 * @param {object} extraProps Get block props value.
 * @param {object} blockType Get block data.
 * @param {object} attributes Get block attributes.
 * @returns {object} extraProps
 */
const saveSidebarSelectAttribute = (extraProps, blockType, attributes) => {
	if (enableSidebarSelectOnBlocks.includes(blockType.name)) {
		const { href, popupButtonMode } = attributes;

		let popupClass = '';

		if (href !== null && href !== undefined) {
			const match = href.match(youtubePattern);

			if (match && match[1].length > 0) {
				popupClass += ' has-youtube-embed has-image-popup';

				if (popupButtonMode) {
					popupClass += ' has-dark-mode';
				}
			}
		}

		extraProps.className += classnames(extraProps.className, popupClass);
	}

	return extraProps;
};
wp.hooks.addFilter(
	'blocks.getSaveContent.extraProps',
	'custom-attributes/save-sidebar-select-attribute',
	saveSidebarSelectAttribute,
);
