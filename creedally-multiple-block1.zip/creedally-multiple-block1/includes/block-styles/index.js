/**
 * Entry point for block styles.
 */

// Each block that needs custom styles should have it's own file.
// import './button'
import './image-block';
