<?php
/**
 * Gutenberg Blocks setup
 *
 * @package TenUpPlugin
 */

namespace TenUpPlugin\Blocks;

use TenUpPlugin\Utility;

/**
 * Set up blocks
 *
 * @return void
 */
function setup() {
	$n = function( $function ) {
		return __NAMESPACE__ . "\\$function";
	};

	add_action( 'enqueue_block_editor_assets', $n( 'blocks_editor_styles' ) );

	add_filter( 'block_categories_all', $n( 'blocks_categories' ), 10, 2 );

	add_action( 'init', $n( 'register_plugin_blocks' ) );

	add_action( 'init', $n( 'register_block_pattern_categories' ) );

	add_action( 'init', $n( 'register_block_styles' ) ); //

	add_action( 'rest_api_init', $n( 'rest_fields' ) ); //

	/*
	If you are using the block library, remove the blocks you don't need.

	add_filter( 'tenup_available_blocks', function ( $blocks ) {
		if ( ! empty( $blocks['integrated-hero'] ) ) {
			unset( $blocks['integrated-hero'] );
		}

		return $blocks;
	} );
	*/
}

/**
 * Enqueue editor-only JavaScript/CSS for blocks.
 *
 * @return void
 */
function blocks_editor_styles() {
	wp_enqueue_style(
		'editor-style-overrides',
		TENUP_PLUGIN_URL . '/build/css/editor-style-overrides.css',
		array(),
		Utility\get_asset_info( 'editor-style-overrides', 'version' )
	);

	if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
		wp_enqueue_script(
			'editor-style-overrides',
			TENUP_PLUGIN_URL . '/build/js/editor-style-overrides.js',
			Utility\get_asset_info( 'editor-style-overrides', 'dependencies' ),
			Utility\get_asset_info( 'editor-style-overrides', 'version' ),
			true
		);
	}

}
/**
 * Automatically registers all blocks that are located within the includes/blocks directory
 *
 * @return void
 */
function register_plugin_blocks() {
    global $wp_version;

    $is_pre_wp_6 = version_compare( $wp_version, '6.0', '<' );

    if ( $is_pre_wp_6 ) {
        add_filter( 'plugins_url', 'pms_filter_plugins_url', 10, 2 );
    }

    if ( file_exists( TENUP_PLUGIN_BLOCK_DIR ) ) {

        $block_json_files = glob(TENUP_PLUGIN_BLOCK_DIR . '*/block.json');

        foreach ( $block_json_files as $filename ) {

            $block_folder = dirname( $filename );

            $block_options = array();

            $markup_file_path = $block_folder . '/markup.php';
            if ( file_exists( $markup_file_path ) ) {

                $block_options['render_callback'] = function( $attributes, $content, $block ) use ( $block_folder ) {

                    $context = $block->context;

                    ob_start();
                    include $block_folder . '/markup.php';
                    return ob_get_clean();
                };
            };

            register_block_type_from_metadata( $block_folder, $block_options );
        }
    }

    if ( $is_pre_wp_6 ) {
        remove_filter( 'plugins_url', 'pms_filter_plugins_url', 10, 2 );
    }
}
function pms_filter_plugins_url( $url, $path ) {

    $file = preg_replace( '/\.\.\//', '', $path );
    return trailingslashit( TENUP_PLUGIN_URL ) . $file;
}
add_action( 'enqueue_block_editor_assets', function () {

});
/**
 * Register All Block Categories
 *
 * @return void
 */
function blocks_categories( $categories ) {
	return array_merge(
		$categories,
		array(
			array(
				'slug'  => 'tenup-plugin-blocks',
				'title' => __( 'Custom Blocks', 'tenup-plugin' ),
			),
		)
	);
}
/**
* Register block pattern categories
*
* @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-patterns/
*
* @return void
*/
function register_block_pattern_categories() {
/**
 * Register Pattern Category
 */
    register_block_pattern_category(
        'pms',
        [
            'label' => esc_html__( 'CreedAlly Client Patterns', 'pms' ),
        ]
    );
    /**
     * Register Pattern
     */
    register_block_pattern(
        'pms/pms-block-pattern',
        [
            'categories'    => [
                'pms',
            ],
            'content'       => '<!-- wp:group -->
            <div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:heading -->
            <h2>Example Block Pattern</h2>
            <!-- /wp:heading -->
            
            <!-- wp:paragraph -->
            <p>Lorem ipsum dolor sit amet labore cras venenatis.</p>
            <!-- /wp:paragraph -->
            
            <!-- wp:columns -->
            <div class="wp-block-columns"><!-- wp:column -->
            <div class="wp-block-column"><!-- wp:heading {"level":3} -->
            <h3>Sub Heading 1</h3>
            <!-- /wp:heading -->
            
            <!-- wp:paragraph -->
            <p>Lorem ipsum dolor sit amet id erat aliquet diam ullamcorper tempus massa eleifend vivamus.</p>
            <!-- /wp:paragraph --></div>
            <!-- /wp:column -->
            
            <!-- wp:column -->
            <div class="wp-block-column"><!-- wp:heading {"level":3} -->
            <h3>Sub Heading 2</h3>
            <!-- /wp:heading -->
            
            <!-- wp:paragraph -->
            <p>Morbi augue cursus quam pulvinar eget volutpat suspendisse dictumst mattis id.</p>
            <!-- /wp:paragraph --></div>
            <!-- /wp:column --></div>
            <!-- /wp:columns --></div></div>
            <!-- /wp:group -->',
            'description'   => 'An pms block pattern',
            'keywords'      => 'pms',
            'title'         => 'CreedAlly Block Pattern',
            'viewportWidth' => 800,
        ],
    );
   
}

/**
 * Register core block styles.
 *
 * @return void
 */
function register_block_styles() {

	register_block_style(
		'core/button',
		array(
			'name'  => 'button-style-1',
			'label' => __( 'Button Style 1', 'everbridge-theme' ),
		)
	);

	register_block_style(
		'core/button',
		array(
			'name'  => 'button-style-2',
			'label' => __( 'Button Style 2', 'everbridge-theme' ),
		)
	);

	register_block_style(
		'core/button',
		array(
			'name'  => 'button-style-4',
			'label' => __( 'Button Style 3', 'everbridge-theme' ),
		)
	);

	register_block_style(
		'core/button',
		array(
			'name'  => 'button-style-6',
			'label' => __( 'Button Style 4', 'everbridge-theme' ),
		)
	);

	register_block_style(
		'core/button',
		array(
			'name'  => 'button-style-3',
			'label' => __( 'Link Style 1', 'everbridge-theme' ),
		)
	);

	register_block_style(
		'core/button',
		array(
			'name'  => 'button-style-5',
			'label' => __( 'Link Style 2', 'everbridge-theme' ),
		)
	);
}

/**
 * Register needed rest fields.
 *
 * @since 1.0.0
 */
function rest_fields() {
	$post_types = get_post_types(
		array(
			'public' => true,
		)
	);

	register_rest_field(
		apply_filters( 'tenup_api_meta_fields_post_types', array_keys( $post_types ) ),
		'get_extra_meta_fields',
		array(
			'get_callback'    => __NAMESPACE__ . '\\rest_get_extra_meta_fields',
			'update_callback' => null,
			'schema'          => null,
		)
	);

	register_rest_field(
		apply_filters( 'tenup_api_meta_fields_post_types', array_keys( $post_types ) ),
		'get_external_url',
		array(
			'get_callback'    => __NAMESPACE__ . '\\rest_get_external_url',
			'update_callback' => null,
			'schema'          => null,
		)
	);

	register_rest_field(
		apply_filters( 'tenup_api_meta_fields_post_types', array_keys( $post_types ) ),
		'get_external_title',
		array(
			'get_callback'    => __NAMESPACE__ . '\\rest_get_external_title',
			'update_callback' => null,
			'schema'          => null,
		)
	);

	register_rest_field(
		apply_filters( 'tenup_api_term_title_post_types', array_keys( $post_types ) ),
		'get_term_title',
		array(
			'get_callback'    => __NAMESPACE__ . '\\rest_get_term_title',
			'update_callback' => null,
			'schema'          => null,
		)
	);
}

/**
 * Get extra meta fields for the rest field.
 *
 * @param array $object Get rest object fields.
 */
function rest_get_extra_meta_fields( $object ) {

	$post_id = ! empty( $object['id'] ) ? esc_attr( $object['id'] ) : '';

	$external_meta = array();
	$post_type     = get_post_type( $post_id );
	$post_excerpt  = get_the_excerpt( $post_id );

	$get_permalink = get_the_permalink( $post_id );

	$default_text = esc_attr__( 'read more', 'everbridge-theme' );

	switch ( $post_type ) {
		case 'news_item':
			$news_fields                   = get_post_meta( $post_id, 'news_fields', true );
			$external_meta['is_summary']   = false;
			$external_meta['description']  = ! empty( $post_excerpt ) ? esc_html( $post_excerpt ) : '';
			$external_meta['external_url'] = ! empty( $news_fields['external_url'] ) ? esc_url( $news_fields['external_url'] ) : esc_url( $get_permalink );
			$external_meta['link_text']    = ! empty( $news_fields['link_text'] ) ? esc_html( $news_fields['link_text'] ) : esc_html( $default_text );
			break;
		case 'resource':
			$resource_fields               = get_post_meta( $post_id, 'resource_fields', true );
			$external_meta['is_summary']   = ! empty( $resource_fields['summary'] ) ? true : false;
			$external_meta['description']  = ! empty( $resource_fields['summary'] ) ? esc_html( $resource_fields['summary'] ) : esc_html( $post_excerpt );
			$external_meta['external_url'] = ! empty( $resource_fields['external_url'] ) ? esc_url( $resource_fields['external_url'] ) : esc_url( $get_permalink );
			$external_meta['link_text']    = ! empty( $resource_fields['link_text'] ) ? esc_html( $resource_fields['link_text'] ) : esc_html( $default_text );
			break;
		default:
			$external_meta['is_summary']   = false;
			$external_meta['description']  = esc_html( $post_excerpt );
			$external_meta['external_url'] = esc_url( $get_permalink );
			$external_meta['link_text']    = esc_html( $default_text );
	}

	return apply_filters( '10up_eb_post_external_meta', $external_meta, $post_id );
}

/**
 * Get external url for the rest field.
 *
 * @param array $object Get rest object fields.
 */
function rest_get_external_url( $object ) {

	$post_type = ! empty( $object['type'] ) ? esc_attr( $object['type'] ) : '';
	$post_id   = ! empty( $object['id'] ) ? esc_attr( $object['id'] ) : '';

	$get_permalink = get_the_permalink( $post_id );

	switch ( $post_type ) {
		case 'news_item':
			$news_fields  = get_post_meta( $post_id, 'news_fields', true );
			$external_url = ! empty( $news_fields['external_url'] ) ? esc_url( $news_fields['external_url'] ) : '';
			break;
		case 'resource':
			$resource_fields = get_post_meta( $post_id, 'resource_fields', true );
			$external_url    = ! empty( $resource_fields['external_url'] ) ? esc_url( $resource_fields['external_url'] ) : '';
			break;
		default:
			$external_url = apply_filters( '10up_eb_get_external_url', '', $object );
	}

	return ! empty( $external_url ) ? esc_url( $external_url ) : esc_url( $get_permalink );
}

/**
 * Get external title for the rest field.
 *
 * @param array $object Get rest object fields.
 */
function rest_get_external_title( $object ) {

	$post_type = ! empty( $object['type'] ) ? esc_attr( $object['type'] ) : '';
	$post_id   = ! empty( $object['id'] ) ? esc_attr( $object['id'] ) : '';

	switch ( $post_type ) {
		case 'news_item':
			$news_fields  = get_post_meta( $post_id, 'news_fields', true );
			$external_url = ! empty( $news_fields['link_text'] ) ? esc_attr( $news_fields['link_text'] ) : '';
			break;
		case 'resource':
			$resource_fields = get_post_meta( $post_id, 'resource_fields', true );
			$external_url    = ! empty( $resource_fields['link_text'] ) ? esc_attr( $resource_fields['link_text'] ) : '';
			break;
		default:
			$external_url = apply_filters( '10up_eb_get_external_title', '', $object );
	}

	return ! empty( $external_url ) ? esc_attr( $external_url ) : esc_attr__( 'read more', 'everbridge-theme' );
}

/**
 * Get Term title for the rest field.
 *
 * @param array $object Get rest object fields.
 *
 * @return array $terms Get terms array with taxonomy.
 */
function rest_get_term_title( $object ) {

	$post_type = ! empty( $object['type'] ) ? esc_attr( $object['type'] ) : '';
	$post_id   = ! empty( $object['id'] ) ? esc_attr( $object['id'] ) : '';

	$get_taxonomies = get_object_taxonomies(
		array(
			'public'    => true,
			'post_type' => $post_type,
		),
		'names'
	);

	$terms = array();

	if ( ! empty( $get_taxonomies ) && is_array( $get_taxonomies ) ) {
		foreach ( $get_taxonomies as $taxonomy ) {
			$term               = get_the_terms( $post_id, $taxonomy );
			$terms[ $taxonomy ] = ! empty( $term[0]->name ) ? $term[0]->name : '';
		}
	}

	return $terms;
}


